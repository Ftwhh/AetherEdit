# AetherEdit — AI video editor for Android

Native Kotlin + Jetpack Compose editor with an After-Effects-style property/keyframe model,
GPU shader effects that run identically in the live preview and the export, and **free** AI
features (on-device segmentation, offline captions, natural-language edit commands).

## What works in this build

| Area | Status |
|---|---|
| Import video / photos / audio (SAF picker) | ✅ |
| Multi-track timeline: Video, Overlay, Text, Audio | ✅ |
| Tap-select, drag-move, edge-trim, pinch-zoom, scrub | ✅ |
| Split at playhead, duplicate, delete, undo/redo (100 steps), autosave | ✅ |
| Transform: position, scale, rotation, opacity — all keyframeable | ✅ |
| Keyframes with linear / ease in / ease out / ease in-out / hold / cubic-bezier | ✅ |
| AE-style "stopwatch": toggle keyframe at playhead, edit value = write keyframe | ✅ |
| 14 GPU effects (color correction, levels, hue, duotone, gaussian blur, sharpen, vignette, chroma key, pixelate, glitch, film grain, glow, mirror, radial zoom blur) — every parameter keyframeable | ✅ |
| Effect stacking, reorder, enable/disable | ✅ |
| Speed (0.25–4×) with pitch-preserved audio, volume | ✅ |
| Text titles (overlay) | ✅ (static style; animation of text position is roadmap) |
| Image overlays | ✅ |
| Export MP4 H.264/AAC via hardware encoder, 9:16 / 16:9 / 1:1 / 4:5 | ✅ |
| AI: natural-language commands ("fade in over 1s", "make it cinematic", "slow motion", "add glitch", "trim 2 to 8") | ✅ offline rules always; Groq/Gemini free tiers or a local OpenAI-compatible server optional |
| AI: auto captions (offline, Vosk) | ✅ needs model asset (see below) |
| AI: background removal (MediaPipe selfie segmentation) | ✅ images → transparent PNG; videos → auto-configured chroma key. needs model asset |
| Multi-layer video compositing (picture-in-picture with video on video) | 🛣 roadmap — Media3 1.4 composites overlays (image/text) onto one video stream; video-on-video needs the VideoCompositor API |
| Masks / shape layers / motion tracking | 🛣 roadmap |

## Build

1. Install Android Studio (Ladybug or newer), open this folder, let it sync (Gradle 8.9, AGP 8.6, Kotlin 2.0).
2. Connect a phone (Android 8+, OpenGL ES 3) and press Run. The project builds without any AI assets; the AI panel then runs in offline-rules mode.

## Add the free AI models (optional, ~45 MB)

* **Background removal** — download `selfie_segmenter.tflite` from the MediaPipe Image Segmenter model page and put it at
  `app/src/main/assets/selfie_segmenter.tflite`.
* **Captions** — download `vosk-model-small-en-us-0.15` (or any Vosk language model), unzip, and copy the *contents* to
  `app/src/main/assets/model-en-us/` (so `assets/model-en-us/am/`, `conf/`, … exist).

## Choose the AI brain (all free)

AI tab → *Brain settings*:

* **Offline (no key)** — rule-based parser, no internet, instant. Default.
* **Groq free** — paste a free Groq API key (Llama-3.3-70B, very fast). Best quality for free.
* **Gemini free** — paste a free Google AI Studio key.
* **Local / custom** — any OpenAI-compatible server, e.g. Ollama on your PC (`http://<pc-ip>:11434/v1`, model `llama3.1`).

Online brains fall back to the offline parser automatically if the request fails.

## Architecture

```
model/        Project ▸ Track ▸ Clip ▸ (props + effects) ▸ AnimatedParam ▸ Keyframe   (kotlinx.serialization, autosaved)
engine/
  Keyframes       interpolation + easing (AE semantics, cubic-bezier solver)
  EffectRegistry  all GPU effects as single-pass GLSL + param specs — add one here, it appears everywhere
  ShaderEffect    Media3 GlEffect that evaluates keyframed uniforms per frame
  EffectBuilder   clip → [transform] → [effects…] → [overlays] → [presentation]
  PreviewEngine   ExoPlayer + setVideoEffects; live uniforms, rebuild only on structural change
  ExportEngine    Media3 Transformer composition (video sequence + mixed audio sequences)
ai/
  EditCommand     the command vocabulary (JSON)
  LlmProvider     Groq / Gemini / custom OpenAI-compatible / offline RuleBasedProvider + fallback chain
  CommandExecutor applies commands to the project (effects, keyframes, trims, splits, text…)
  BackgroundRemover (MediaPipe), AutoCaptions (Vosk + MediaCodec PCM decode)
ui/           Compose: EditorScreen, Timeline (Canvas + gestures), Inspector, Effects, AI, Export
viewmodel/    EditorViewModel: history, selection, playhead, keyframe editing, AI orchestration
```

### Adding an effect
Add one `register(EffectType(...))` in `EffectRegistry` with a fragment shader using `uTexSampler`,
`vTexSamplingCoord`, `uTexSize`, `uTime` and `u_<param>` uniforms. Done — it shows in the effects
browser, the inspector (keyframeable), the AI vocabulary and the exporter.

## Known limits of this first build
* The main video track is a sequence (clips play back-to-back); gaps on audio tracks are collapsed (Media3 1.4 has no silence item).
* Text/image overlays are composited centred at their natural size; per-overlay transform keyframes are the next step.
* Preview applies the effect chain of the clip currently under the playhead; effect chains on other video clips are applied as the playlist advances.
