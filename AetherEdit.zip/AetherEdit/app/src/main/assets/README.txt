Place selfie_segmenter.tflite and model-en-us/ here (see README).
