package com.aetheredit

import android.app.Application

class AetherApp : Application()
