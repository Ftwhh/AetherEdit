package com.aetheredit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.media3.common.util.UnstableApi
import com.aetheredit.ui.EditorScreen
import com.aetheredit.ui.theme.AetherTheme
import com.aetheredit.viewmodel.EditorViewModel

@UnstableApi
class MainActivity : ComponentActivity() {
    private val vm: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AetherTheme { EditorScreen(vm) } }
    }

    override fun onPause() { super.onPause(); vm.preview.pause() }
}
