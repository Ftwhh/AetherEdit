package com.aetheredit.ai

import android.content.Context

/** Which free brain to use. Keys are stored locally only and sent to the chosen provider only. */
enum class AiBackend { OFFLINE, GROQ, GEMINI, CUSTOM_OPENAI }

class AiSettings(context: Context) {
    private val prefs = context.getSharedPreferences("ai", Context.MODE_PRIVATE)

    var backend: AiBackend
        get() = runCatching { AiBackend.valueOf(prefs.getString("backend", AiBackend.OFFLINE.name)!!) }.getOrDefault(AiBackend.OFFLINE)
        set(v) = prefs.edit().putString("backend", v.name).apply()

    var apiKey: String
        get() = prefs.getString("key", "") ?: ""
        set(v) = prefs.edit().putString("key", v.trim()).apply()

    var customBaseUrl: String
        get() = prefs.getString("baseUrl", "http://192.168.1.10:11434/v1") ?: ""
        set(v) = prefs.edit().putString("baseUrl", v.trim()).apply()

    var customModel: String
        get() = prefs.getString("model", "llama3.1") ?: ""
        set(v) = prefs.edit().putString("model", v.trim()).apply()

    /** Builds the provider chain: chosen online provider first, offline rules as fallback. */
    fun provider(): LlmProvider {
        val primary: LlmProvider? = when (backend) {
            AiBackend.OFFLINE -> null
            AiBackend.GROQ -> apiKey.takeIf { it.isNotBlank() }?.let { OpenAiCompatibleProvider(it) }
            AiBackend.GEMINI -> apiKey.takeIf { it.isNotBlank() }?.let { GeminiProvider(it) }
            AiBackend.CUSTOM_OPENAI -> OpenAiCompatibleProvider(apiKey.ifBlank { "none" }, customBaseUrl, customModel, "Custom / local")
        }
        return if (primary == null) RuleBasedProvider() else FallbackProvider(primary, RuleBasedProvider())
    }
}

/** Tries the online provider; if it throws or returns only a "say", falls back to the offline rules. */
class FallbackProvider(private val primary: LlmProvider, private val fallback: LlmProvider) : LlmProvider {
    override val name get() = primary.name
    override suspend fun parse(instruction: String, context: ClipContext): List<EditCommand> {
        val r = runCatching { primary.parse(instruction, context) }.getOrNull()
        return if (r == null || r.all { it is EditCommand.Say }) fallback.parse(instruction, context) else r
    }
}
