package com.aetheredit.ai

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.aetheredit.model.Clip
import com.aetheredit.model.MediaKind
import com.aetheredit.model.TextStyle
import com.aetheredit.model.secToUs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.float
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.StorageService
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

data class CaptionSegment(val text: String, val startSec: Float, val endSec: Float)

/**
 * Free offline speech-to-text with Vosk. Put a model folder (e.g. vosk-model-small-en-us-0.15,
 * ~40 MB, Apache-2.0) in app/src/main/assets/model-en-us/. Works for any Vosk language model.
 */
class AutoCaptions(private val context: Context) {

    private var model: Model? = null

    private suspend fun model(): Model = model ?: suspendCancellableCoroutine { cont ->
        StorageService.unpack(context, "model-en-us", "model",
            { m -> model = m; cont.resume(m) },
            { e -> cont.resumeWithException(e) })
    }

    fun isModelAvailable(): Boolean = runCatching { context.assets.list("model-en-us")?.isNotEmpty() == true }.getOrDefault(false)

    suspend fun transcribe(uri: Uri, inPointUs: Long, outPointUs: Long): List<CaptionSegment> = withContext(Dispatchers.Default) {
        val m = model()
        val extractor = MediaExtractor().apply { setDataSource(context, uri, null) }
        val trackIndex = (0 until extractor.trackCount).firstOrNull {
            extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
        } ?: error("No audio track")
        extractor.selectTrack(trackIndex)
        val format = extractor.getTrackFormat(trackIndex)
        val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        extractor.seekTo(inPointUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

        val codec = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(format, null, null, 0)
        codec.start()

        val rec = Recognizer(m, sampleRate.toFloat()).apply { setWords(true) }
        val words = mutableListOf<Triple<String, Float, Float>>()
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        val mono = ByteArray(1 shl 16)

        fun collect(json: String) {
            val obj = runCatching { Json.parseToJsonElement(json).jsonObject }.getOrNull() ?: return
            obj["result"]?.jsonArray?.forEach { w ->
                val o = w.jsonObject
                words += Triple(o["word"]!!.jsonPrimitive.content, o["start"]!!.jsonPrimitive.float, o["end"]!!.jsonPrimitive.float)
            }
        }

        while (!outputDone) {
            if (!inputDone) {
                val idx = codec.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    val buf = codec.getInputBuffer(idx)!!
                    val n = extractor.readSampleData(buf, 0)
                    if (n < 0 || extractor.sampleTime > outPointUs) {
                        codec.queueInputBuffer(idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true
                    } else {
                        codec.queueInputBuffer(idx, 0, n, extractor.sampleTime, 0); extractor.advance()
                    }
                }
            }
            val outIdx = codec.dequeueOutputBuffer(info, 10_000)
            if (outIdx >= 0) {
                val out = codec.getOutputBuffer(outIdx)!!
                out.order(ByteOrder.LITTLE_ENDIAN)
                val frames = info.size / 2 / channels
                val needed = frames * 2
                val m16 = if (needed > mono.size) ByteArray(needed) else mono
                val bb = ByteBuffer.wrap(m16).order(ByteOrder.LITTLE_ENDIAN)
                for (f in 0 until frames) {
                    var acc = 0
                    for (c in 0 until channels) acc += out.getShort(info.offset + (f * channels + c) * 2)
                    bb.putShort((acc / channels).toShort())
                }
                if (needed > 0) { if (rec.acceptWaveForm(m16, needed)) collect(rec.result) }
                codec.releaseOutputBuffer(outIdx, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
            }
        }
        collect(rec.finalResult)
        rec.close(); codec.stop(); codec.release(); extractor.release()

        // Group words into ~2.5 s caption segments, times relative to clip in-point
        val offset = inPointUs / 1_000_000f
        val segments = mutableListOf<CaptionSegment>()
        var cur = mutableListOf<Triple<String, Float, Float>>()
        for (w in words) {
            if (cur.isNotEmpty() && (w.third - cur.first().second > 2.5f || cur.size >= 7)) {
                segments += CaptionSegment(cur.joinToString(" ") { it.first }, cur.first().second - offset, cur.last().third - offset); cur = mutableListOf()
            }
            cur += w
        }
        if (cur.isNotEmpty()) segments += CaptionSegment(cur.joinToString(" ") { it.first }, cur.first().second - offset, cur.last().third - offset)
        segments.filter { it.endSec > 0f }
    }

    /** Converts caption segments into TEXT clips positioned on the timeline under [clip]. */
    fun toTextClips(clip: Clip, segments: List<CaptionSegment>): List<Clip> = segments.map { s ->
        val start = (clip.timelineStartUs + (s.startSec.coerceAtLeast(0f) / clip.speedValue()).secToUs())
        val dur = ((s.endSec - s.startSec.coerceAtLeast(0f)).coerceAtLeast(0.6f) / clip.speedValue()).secToUs()
        Clip(
            name = s.text, uri = "", kind = MediaKind.TEXT,
            timelineStartUs = start, inPointUs = 0, outPointUs = dur, sourceDurationUs = Long.MAX_VALUE / 4,
            textStyle = TextStyle(text = s.text, fontSizePx = 64),
        )
    }

    fun close() { model?.close(); model = null }
}
