package com.aetheredit.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.ByteBufferExtractor
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.imagesegmenter.ImageSegmenter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Free, on-device person segmentation with MediaPipe's selfie segmenter.
 *
 * - For images: produces a PNG with a transparent background (usable as an overlay clip).
 * - For videos: samples a frame, segments it and returns the dominant *background* colour so the
 *   GPU chroma-key effect can be auto-configured. This keeps background removal real-time inside the
 *   Media3 pipeline on any phone, without per-frame ML inference.
 *
 * Model file: put `selfie_segmenter.tflite` (Apache-2.0, from MediaPipe) in app/src/main/assets/.
 */
class BackgroundRemover(private val context: Context) {

    private val segmenter: ImageSegmenter by lazy {
        val opts = ImageSegmenter.ImageSegmenterOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath(MODEL_ASSET).build())
            .setRunningMode(RunningMode.IMAGE)
            .setOutputCategoryMask(false)
            .setOutputConfidenceMasks(true)
            .build()
        ImageSegmenter.createFromOptions(context, opts)
    }

    fun isModelAvailable(): Boolean = runCatching { context.assets.open(MODEL_ASSET).close(); true }.getOrDefault(false)

    /** Returns a float[w*h] person-probability mask (0..1) for the bitmap. */
    suspend fun personMask(bitmap: Bitmap): FloatArray = withContext(Dispatchers.Default) {
        val argb = if (bitmap.config == Bitmap.Config.ARGB_8888) bitmap else bitmap.copy(Bitmap.Config.ARGB_8888, false)
        val result = segmenter.segment(BitmapImageBuilder(argb).build())
        val mask = result.confidenceMasks().get()[0]
        val buf = ByteBufferExtractor.extract(mask).asFloatBuffer()
        val out = FloatArray(mask.width * mask.height)
        buf.get(out)
        out
    }

    /** Cuts the background out of an image and writes a PNG; returns its Uri. */
    suspend fun cutoutImage(src: Uri): Uri = withContext(Dispatchers.Default) {
        val bmp = com.aetheredit.engine.EffectBuilder.loadBitmap(context, src.toString()) ?: error("Cannot decode image")
        val mask = personMask(bmp)
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val a = (mask[i].coerceIn(0f, 1f) * 255).toInt()
            px[i] = (a shl 24) or (px[i] and 0x00FFFFFF)
        }
        val out = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        val file = File(context.cacheDir, "cutout_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
        Uri.fromFile(file)
    }

    /** Samples a video frame and estimates the background colour behind the subject (for chroma key). */
    suspend fun estimateBackgroundColor(video: Uri, atUs: Long): FloatArray = withContext(Dispatchers.Default) {
        val frame = MediaMetadataRetriever().use { r ->
            r.setDataSource(context, video)
            r.getScaledFrameAtTime(atUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 256, 256)
        } ?: error("Cannot read frame")
        val mask = personMask(frame)
        val w = frame.width; val h = frame.height
        var r = 0.0; var g = 0.0; var b = 0.0; var n = 0
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            if (mask.getOrElse(i) { 1f } < 0.2f) {
                val c = frame.getPixel(x, y)
                r += Color.red(c); g += Color.green(c); b += Color.blue(c); n++
            }
        }
        if (n == 0) floatArrayOf(0f, 1f, 0f) else floatArrayOf((r / n / 255).toFloat(), (g / n / 255).toFloat(), (b / n / 255).toFloat())
    }

    fun close() = runCatching { segmenter.close() }

    companion object { const val MODEL_ASSET = "selfie_segmenter.tflite" }
}
