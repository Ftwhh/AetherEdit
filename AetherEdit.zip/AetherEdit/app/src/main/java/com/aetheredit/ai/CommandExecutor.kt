package com.aetheredit.ai

import com.aetheredit.engine.EffectRegistry
import com.aetheredit.model.AnimatedParam
import com.aetheredit.model.Clip
import com.aetheredit.model.Easing
import com.aetheredit.model.EffectInstance
import com.aetheredit.model.Keyframe
import com.aetheredit.model.MediaKind
import com.aetheredit.model.Project
import com.aetheredit.model.Prop
import com.aetheredit.model.TextStyle
import com.aetheredit.model.TrackKind
import com.aetheredit.model.secToUs

/** Applies [EditCommand]s to a project. Returns the new project plus human-readable notes. */
object CommandExecutor {

    data class Result(val project: Project, val notes: List<String>, val needsCaptions: Boolean = false, val needsBgRemoval: Boolean = false)

    fun apply(project: Project, clipId: String, commands: List<EditCommand>): Result {
        var p = project
        val notes = mutableListOf<String>()
        var captions = false
        var bg = false

        for (cmd in commands) {
            val (track, clip) = p.findClip(clipId) ?: break
            when (cmd) {
                is EditCommand.Say -> notes += cmd.message

                is EditCommand.AddEffect -> {
                    val type = EffectRegistry.byId(cmd.effect) ?: EffectRegistry.byName(cmd.effect)
                    if (type == null) { notes += "Unknown effect ${cmd.effect}"; continue }
                    val existing = clip.effects.firstOrNull { it.typeId == type.id }
                    val base = existing ?: type.newInstance()
                    val params = base.params + cmd.params.filterKeys { k -> type.params.any { it.id == k } }
                        .mapValues { (k, v) -> AnimatedParam.of(clamp(type, k, v)) }
                    val inst = base.copy(params = params)
                    p = p.updateClip(clipId) { c ->
                        c.copy(effects = if (existing == null) c.effects + inst else c.effects.map { if (it.id == inst.id) inst else it })
                    }
                    notes += "Added ${type.name}"
                }

                is EditCommand.SetParam -> {
                    p = setOrAnimate(p, clipId, cmd.property, AnimatedParam.of(cmd.value)) ?: p.also { notes += "Unknown property ${cmd.property}" }
                    notes += "Set ${cmd.property} = ${cmd.value}"
                }

                is EditCommand.Animate -> {
                    val easing = runCatching { Easing.valueOf(cmd.easing.uppercase()) }.getOrDefault(Easing.EASE_IN_OUT)
                    val kfs = cmd.keyframes.filter { it.size >= 2 }.map { Keyframe(it[0].secToUs(), it[1], easing) }.sortedBy { it.timeUs }
                    if (kfs.isEmpty()) continue
                    val existing = currentParam(clip, cmd.property)
                    val merged = kfs.fold(existing ?: AnimatedParam.of(kfs.first().value)) { acc, kf -> acc.withKeyframe(kf) }
                    p = setOrAnimate(p, clipId, cmd.property, merged) ?: p.also { notes += "Unknown property ${cmd.property}" }
                    notes += "Animated ${cmd.property} (${kfs.size} keyframes)"
                }

                is EditCommand.Trim -> {
                    val start = cmd.start?.secToUs()?.let { clip.inPointUs + it } ?: clip.inPointUs
                    val end = cmd.end?.secToUs()?.let { clip.inPointUs + it } ?: clip.outPointUs
                    if (end > start) {
                        p = p.updateClip(clipId) { it.copy(inPointUs = start, outPointUs = end) }
                        notes += "Trimmed"
                    }
                }

                is EditCommand.Split -> {
                    val atUs = clip.timelineStartUs + cmd.at.secToUs()
                    p = split(p, clipId, atUs)
                    notes += "Split at ${cmd.at}s"
                }

                is EditCommand.Speed -> {
                    p = p.updateClip(clipId) { it.withProp(Prop.SPEED, AnimatedParam.of(cmd.factor.coerceIn(0.1f, 8f))) }
                    notes += "Speed ${cmd.factor}x"
                }

                is EditCommand.AddText -> {
                    val textTrack = p.tracks.firstOrNull { it.kind == TrackKind.TEXT } ?: continue
                    val t = Clip(
                        name = cmd.text, uri = "", kind = MediaKind.TEXT,
                        timelineStartUs = clip.timelineStartUs + cmd.start.secToUs(),
                        inPointUs = 0, outPointUs = cmd.duration.secToUs(), sourceDurationUs = Long.MAX_VALUE / 4,
                        textStyle = TextStyle(text = cmd.text, fontSizePx = cmd.size),
                    )
                    p = p.addClip(textTrack.id, t)
                    notes += "Added text “${cmd.text}”"
                }

                EditCommand.RemoveBackground -> { bg = true; notes += "Background removal queued" }
                EditCommand.AutoCaptions -> { captions = true; notes += "Generating captions…" }
                EditCommand.DeleteClip -> { p = p.removeClip(clipId); notes += "Deleted clip" }
            }
        }
        return Result(p, notes, captions, bg)
    }

    fun split(project: Project, clipId: String, atTimelineUs: Long): Project {
        val (track, clip) = project.findClip(clipId) ?: return project
        if (atTimelineUs <= clip.timelineStartUs || atTimelineUs >= clip.timelineEndUs) return project
        val localUs = ((atTimelineUs - clip.timelineStartUs) * clip.speedValue()).toLong()
        val left = clip.copy(outPointUs = clip.inPointUs + localUs)
        val right = clip.copy(
            id = java.util.UUID.randomUUID().toString(),
            inPointUs = clip.inPointUs + localUs,
            timelineStartUs = atTimelineUs,
            // shift keyframes so they stay in place on the timeline
            props = clip.props.mapValues { (_, p) -> shift(p, -(atTimelineUs - clip.timelineStartUs)) },
            effects = clip.effects.map { e -> e.copy(id = java.util.UUID.randomUUID().toString(), params = e.params.mapValues { (_, p) -> shift(p, -(atTimelineUs - clip.timelineStartUs)) }) },
        )
        return project.copy(tracks = project.tracks.map { t ->
            if (t.id != track.id) t else t.copy(clips = t.clips.flatMap { if (it.id == clipId) listOf(left, right) else listOf(it) }.sortedBy { it.timelineStartUs })
        })
    }

    private fun shift(p: AnimatedParam, deltaUs: Long) = p.copy(keyframes = p.keyframes.map { it.copy(timeUs = it.timeUs + deltaUs) })

    private fun currentParam(clip: Clip, property: String): AnimatedParam? {
        if (property in Prop.defaults.keys) return clip.prop(property)
        val (eff, param) = property.split('.', limit = 2).let { if (it.size == 2) it[0] to it[1] else return null }
        return clip.effects.firstOrNull { it.typeId == eff }?.params?.get(param)
    }

    /** Sets a transform prop or "effect.param" (creating the effect if needed). Returns null if the property is unknown. */
    private fun setOrAnimate(project: Project, clipId: String, property: String, value: AnimatedParam): Project? {
        if (property in Prop.defaults.keys) return project.updateClip(clipId) { it.withProp(property, value) }
        val parts = property.split('.', limit = 2)
        if (parts.size != 2) return null
        val type = EffectRegistry.byId(parts[0]) ?: return null
        if (type.params.none { it.id == parts[1] }) return null
        return project.updateClip(clipId) { c ->
            val existing = c.effects.firstOrNull { it.typeId == type.id } ?: type.newInstance()
            val inst = existing.copy(params = existing.params + (parts[1] to value))
            c.copy(effects = if (c.effects.any { it.id == inst.id }) c.effects.map { if (it.id == inst.id) inst else it } else c.effects + inst)
        }
    }

    private fun clamp(type: com.aetheredit.engine.EffectType, k: String, v: Float): Float {
        val s = type.params.first { it.id == k }
        return v.coerceIn(s.min, s.max)
    }

    fun EffectInstance.displayName() = EffectRegistry.byId(typeId)?.name ?: typeId
}
