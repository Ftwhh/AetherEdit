package com.aetheredit.ai

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * The vocabulary the AI speaks. Both the LLM providers and the offline rule-based parser emit
 * these; [CommandExecutor] applies them to the project. Times are seconds relative to the clip.
 */
@Serializable
sealed class EditCommand {
    @Serializable @SerialName("add_effect")
    data class AddEffect(val effect: String, val params: Map<String, Float> = emptyMap()) : EditCommand()

    @Serializable @SerialName("set")
    data class SetParam(val property: String, val value: Float) : EditCommand()

    /** Animate a property: list of (time, value) pairs. property may be a transform prop or "effect.param". */
    @Serializable @SerialName("animate")
    data class Animate(val property: String, val keyframes: List<List<Float>>, val easing: String = "ease_in_out") : EditCommand()

    @Serializable @SerialName("trim")
    data class Trim(val start: Float? = null, val end: Float? = null) : EditCommand()

    @Serializable @SerialName("split")
    data class Split(val at: Float) : EditCommand()

    @Serializable @SerialName("speed")
    data class Speed(val factor: Float) : EditCommand()

    @Serializable @SerialName("add_text")
    data class AddText(val text: String, val start: Float = 0f, val duration: Float = 3f, val size: Int = 96) : EditCommand()

    @Serializable @SerialName("remove_background")
    data object RemoveBackground : EditCommand()

    @Serializable @SerialName("auto_captions")
    data object AutoCaptions : EditCommand()

    @Serializable @SerialName("delete_clip")
    data object DeleteClip : EditCommand()

    @Serializable @SerialName("say")
    data class Say(val message: String) : EditCommand()
}
