package com.aetheredit.ai

import com.aetheredit.engine.EffectRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/** Turns a natural-language instruction into a list of [EditCommand]s. */
interface LlmProvider {
    val name: String
    suspend fun parse(instruction: String, context: ClipContext): List<EditCommand>
}

data class ClipContext(
    val clipName: String,
    val durationSec: Float,
    val currentEffects: List<String>,
)

object Prompts {
    val json = Json { ignoreUnknownKeys = true; classDiscriminator = "type"; encodeDefaults = true; isLenient = true }

    fun system(): String {
        val effects = EffectRegistry.all.joinToString("\n") { e ->
            "- ${e.id}: ${e.name} (params: ${e.params.joinToString { "${it.id} ${it.min}..${it.max} default ${it.default}" }})"
        }
        return """
You are the command brain of a mobile video editor. Convert the user's request into a JSON array of commands.
Output ONLY the JSON array, nothing else.

Command schema (field "type" selects the command):
{"type":"add_effect","effect":"<effect id>","params":{"<param>":<number>}}
{"type":"set","property":"<prop>","value":<number>}          props: position.x position.y (-1..1), scale (1=100%), rotation (deg), opacity (0..1), volume (0..2), speed; or "<effect>.<param>"
{"type":"animate","property":"<prop>","keyframes":[[<timeSec>,<value>],...],"easing":"linear|ease_in|ease_out|ease_in_out|hold"}
{"type":"trim","start":<sec>,"end":<sec>}
{"type":"split","at":<sec>}
{"type":"speed","factor":<number>}
{"type":"add_text","text":"...","start":<sec>,"duration":<sec>,"size":<px>}
{"type":"remove_background"}
{"type":"auto_captions"}
{"type":"delete_clip"}
{"type":"say","message":"short reply when you cannot do something"}

Available effects:
$effects

Rules: a "fade in" is an opacity animation 0->1; "fade out" ends at the clip end; "zoom in" animates scale; "ken burns" animates scale 1->1.15 and a slight position move; "cinematic" = color (contrast 1.15, saturation 0.9) + vignette; "slow motion" = speed 0.5. Combine multiple commands when needed.
""".trimIndent()
    }

    fun user(instruction: String, ctx: ClipContext) =
        "Clip: ${ctx.clipName}, duration ${"%.2f".format(ctx.durationSec)}s, effects already applied: ${ctx.currentEffects.ifEmpty { listOf("none") }}.\nRequest: $instruction"

    fun decode(text: String): List<EditCommand> {
        val start = text.indexOf('[')
        val end = text.lastIndexOf(']')
        if (start < 0 || end <= start) return listOf(EditCommand.Say(text.take(200)))
        val arr = runCatching { json.parseToJsonElement(text.substring(start, end + 1)).jsonArray }.getOrNull()
            ?: return listOf(EditCommand.Say("Could not understand the AI reply."))
        return arr.mapNotNull { el -> runCatching { json.decodeFromJsonElement(EditCommand.serializer(), el) }.getOrNull() }
    }
}

/**
 * Free hosted model via an OpenAI-compatible chat endpoint. Default is Groq's free tier
 * (fast Llama 3.3 70B). Any OpenAI-compatible server works (OpenRouter free models, a local
 * llama.cpp / Ollama server on your network, etc.).
 */
class OpenAiCompatibleProvider(
    private val apiKey: String,
    private val baseUrl: String = "https://api.groq.com/openai/v1",
    private val model: String = "llama-3.3-70b-versatile",
    override val name: String = "Groq (free)",
) : LlmProvider {
    private val client = OkHttpClient.Builder().callTimeout(40, TimeUnit.SECONDS).build()

    override suspend fun parse(instruction: String, context: ClipContext): List<EditCommand> = withContext(Dispatchers.IO) {
        val body = buildJsonObject {
            put("model", model)
            put("temperature", 0.1)
            putJsonArray("messages") {
                add(buildJsonObject { put("role", "system"); put("content", Prompts.system()) })
                add(buildJsonObject { put("role", "user"); put("content", Prompts.user(instruction, context)) })
            }
        }
        val req = Request.Builder()
            .url("$baseUrl/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { resp ->
            val txt = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) return@withContext listOf(EditCommand.Say("AI error ${resp.code}: ${txt.take(120)}"))
            val content = Prompts.json.parseToJsonElement(txt).jsonObject["choices"]!!.jsonArray[0]
                .jsonObject["message"]!!.jsonObject["content"]!!.jsonPrimitive.content
            Prompts.decode(content)
        }
    }
}

/** Google Gemini free tier (generativelanguage API). */
class GeminiProvider(
    private val apiKey: String,
    private val model: String = "gemini-2.0-flash",
) : LlmProvider {
    override val name = "Gemini (free)"
    private val client = OkHttpClient.Builder().callTimeout(40, TimeUnit.SECONDS).build()

    override suspend fun parse(instruction: String, context: ClipContext): List<EditCommand> = withContext(Dispatchers.IO) {
        val body = buildJsonObject {
            put("system_instruction", buildJsonObject { putJsonArray("parts") { add(buildJsonObject { put("text", Prompts.system()) }) } })
            putJsonArray("contents") {
                add(buildJsonObject {
                    put("role", "user")
                    putJsonArray("parts") { add(buildJsonObject { put("text", Prompts.user(instruction, context)) }) }
                })
            }
        }
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { resp ->
            val txt = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) return@withContext listOf(EditCommand.Say("AI error ${resp.code}: ${txt.take(120)}"))
            val content = Prompts.json.parseToJsonElement(txt).jsonObject["candidates"]!!.jsonArray[0]
                .jsonObject["content"]!!.jsonObject["parts"]!!.jsonArray[0].jsonObject["text"]!!.jsonPrimitive.content
            Prompts.decode(content)
        }
    }
}

/**
 * 100% offline, zero-cost fallback: a rule-based parser that understands the common editing
 * phrases. Used automatically when no API key is configured or the network is unavailable.
 */
class RuleBasedProvider : LlmProvider {
    override val name = "Offline rules"

    override suspend fun parse(instruction: String, context: ClipContext): List<EditCommand> {
        val s = instruction.lowercase().trim()
        val out = mutableListOf<EditCommand>()
        val dur = context.durationSec
        val num = Regex("(-?\\d+(?:\\.\\d+)?)").find(s)?.groupValues?.get(1)?.toFloatOrNull()
        val secs = Regex("(\\d+(?:\\.\\d+)?)\\s*(s|sec|second)").find(s)?.groupValues?.get(1)?.toFloatOrNull()

        fun has(vararg k: String) = k.any { it in s }

        when {
            has("fade in") -> out += EditCommand.Animate("opacity", listOf(listOf(0f, 0f), listOf(secs ?: 1f, 1f)))
            has("fade out") -> out += EditCommand.Animate("opacity", listOf(listOf(dur - (secs ?: 1f), 1f), listOf(dur, 0f)))
        }
        if (has("zoom in") || has("ken burns")) out += EditCommand.Animate("scale", listOf(listOf(0f, 1f), listOf(dur, 1.15f)))
        if (has("zoom out")) out += EditCommand.Animate("scale", listOf(listOf(0f, 1.15f), listOf(dur, 1f)))
        if (has("spin", "rotate")) out += if (has("spin")) EditCommand.Animate("rotation", listOf(listOf(0f, 0f), listOf(dur, 360f)), "linear")
                                         else EditCommand.SetParam("rotation", num ?: 90f)
        if (has("slow motion", "slow mo", "slowmo")) out += EditCommand.Speed(num?.takeIf { it < 1f } ?: 0.5f)
        else if (has("speed up", "faster", "timelapse")) out += EditCommand.Speed(num?.takeIf { it > 1f } ?: 2f)
        else if (has("speed")) num?.let { out += EditCommand.Speed(it) }
        if (has("mute")) out += EditCommand.SetParam("volume", 0f)
        else if (has("volume")) num?.let { out += EditCommand.SetParam("volume", (it / 100f).coerceIn(0f, 2f)) }
        if (has("black and white", "grayscale", "b&w")) out += EditCommand.AddEffect("color", mapOf("saturation" to 0f))
        if (has("cinematic", "film look", "movie look")) {
            out += EditCommand.AddEffect("color", mapOf("contrast" to 1.15f, "saturation" to 0.9f))
            out += EditCommand.AddEffect("vignette", mapOf("amount" to 0.45f))
        }
        if (has("warm")) out += EditCommand.AddEffect("color", mapOf("temperature" to 0.4f))
        if (has("cool", "cold")) out += EditCommand.AddEffect("color", mapOf("temperature" to -0.4f))
        if (has("bright")) out += EditCommand.AddEffect("color", mapOf("brightness" to 0.15f))
        if (has("dark")) out += EditCommand.AddEffect("color", mapOf("brightness" to -0.15f))
        if (has("blur")) out += EditCommand.AddEffect("blur", mapOf("radius" to (num ?: 8f)))
        if (has("sharpen")) out += EditCommand.AddEffect("sharpen")
        if (has("vignette")) out += EditCommand.AddEffect("vignette")
        if (has("glitch")) out += EditCommand.AddEffect("glitch")
        if (has("grain", "film grain")) out += EditCommand.AddEffect("grain")
        if (has("glow", "bloom")) out += EditCommand.AddEffect("glow")
        if (has("pixel")) out += EditCommand.AddEffect("pixelate")
        if (has("mirror")) out += EditCommand.AddEffect("mirror")
        if (has("duotone")) out += EditCommand.AddEffect("duotone")
        if (has("green screen", "chroma", "remove background", "remove the background", "cut out background")) out += EditCommand.RemoveBackground
        if (has("caption", "subtitle", "transcri")) out += EditCommand.AutoCaptions
        if (has("split", "cut at")) (secs ?: num)?.let { out += EditCommand.Split(it) }
        if (has("trim")) {
            val range = Regex("(\\d+(?:\\.\\d+)?)\\s*(?:to|-|and)\\s*(\\d+(?:\\.\\d+)?)").find(s)
            if (range != null) out += EditCommand.Trim(range.groupValues[1].toFloat(), range.groupValues[2].toFloat())
            else if (has("first")) secs?.let { out += EditCommand.Trim(start = it) }
            else if (has("last")) secs?.let { out += EditCommand.Trim(end = dur - it) }
        }
        if (has("delete", "remove clip")) out += EditCommand.DeleteClip
        Regex("(?:text|title|caption)\\s+(?:saying|that says|:)?\\s*[\"“](.+?)[\"”]").find(instruction)?.let {
            out += EditCommand.AddText(it.groupValues[1], 0f, secs ?: 3f)
        }

        if (out.isEmpty()) out += EditCommand.Say("I didn't catch that. Try: \"fade in over 1 second\", \"make it cinematic\", \"slow motion\", \"add blur 10\", \"remove background\".")
        return out
    }
}
