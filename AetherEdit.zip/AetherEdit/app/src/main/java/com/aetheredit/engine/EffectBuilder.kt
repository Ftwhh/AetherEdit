package com.aetheredit.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import com.aetheredit.model.Clip
import com.aetheredit.model.MediaKind
import com.aetheredit.model.Project
import com.aetheredit.model.Prop
import com.aetheredit.model.TrackKind
import com.google.common.collect.ImmutableList

/**
 * Turns the project model into a Media3 effect chain for a clip:
 *   [built-in transform] -> [user effects in order] -> [overlays from TEXT/OVERLAY tracks] -> [presentation size]
 */
@UnstableApi
object EffectBuilder {

    /**
     * @param timeOffsetUs presentation time at which this clip's local time 0 occurs. For the preview this is the
     * clip's position in the player; for export inside a sequence it's the same value.
     */
    fun forClip(context: Context, project: Project, clip: Clip, timeOffsetUs: Long): List<Effect> =
        forClip(context, project, clip, timeOffsetUs) { clip }

    /**
     * [live] is read on every frame, so parameter and keyframe edits show up instantly in the preview
     * without rebuilding the GL pipeline. The pipeline *structure* (which shaders, in which order) is
     * fixed from [clip]; see [chainSignature].
     */
    fun forClip(context: Context, project: Project, clip: Clip, timeOffsetUs: Long, live: () -> Clip): List<Effect> {
        val effects = mutableListOf<Effect>()

        // 1. transform + opacity, keyframeable
        effects += ShaderEffect(EffectRegistry.TRANSFORM_SHADER, { t ->
            val c = live()
            mapOf(
                "u_posx" to f(Keyframes.evaluate(c.prop(Prop.POS_X), t)),
                "u_posy" to f(Keyframes.evaluate(c.prop(Prop.POS_Y), t)),
                "u_scale" to f(Keyframes.evaluate(c.prop(Prop.SCALE), t)),
                "u_rotation" to f(Keyframes.evaluate(c.prop(Prop.ROTATION), t)),
                "u_opacity" to f(Keyframes.evaluate(c.prop(Prop.OPACITY), t)),
            )
        }, timeOffsetUs)

        // 2. user effects
        for ((index, inst) in clip.effects.withIndex()) {
            if (!inst.enabled) continue
            val type = EffectRegistry.byId(inst.typeId) ?: continue
            effects += ShaderEffect(type.fragmentShader, { t ->
                val cur = live().effects.getOrNull(index)?.takeIf { it.id == inst.id } ?: inst
                type.params.associate { spec ->
                    val p = cur.params[spec.id]
                    "u_${spec.id}" to f(p?.let { Keyframes.evaluate(it, t) } ?: spec.default)
                }
            }, timeOffsetUs)
        }

        // 3. overlays that overlap this clip in time (text + image overlays)
        val overlays = overlaysFor(context, project, clip)
        if (overlays.isNotEmpty()) effects += OverlayEffect(ImmutableList.copyOf(overlays))

        // 4. conform to project size
        effects += Presentation.createForWidthAndHeight(project.width, project.height, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
        return effects
    }

    /** Changes to this string mean the GL chain must be rebuilt (effects added/removed/reordered/toggled, overlays changed). */
    fun chainSignature(project: Project, clip: Clip): String {
        val overlays = project.tracks.filter { it.visible && (it.kind == TrackKind.TEXT || it.kind == TrackKind.OVERLAY) }
            .flatMap { it.clips }.filter { it.timelineStartUs < clip.timelineEndUs && it.timelineEndUs > clip.timelineStartUs }
            .joinToString { "${it.id}:${it.textStyle?.text}:${it.textStyle?.fontSizePx}:${it.uri}" }
        return clip.id + "|" + clip.effects.joinToString { "${it.id}:${it.enabled}" } + "|" + overlays + "|${project.width}x${project.height}"
    }

    private fun overlaysFor(context: Context, project: Project, clip: Clip): List<TextureOverlay> {
        val list = mutableListOf<TextureOverlay>()
        for (track in project.tracks.filter { it.visible && (it.kind == TrackKind.TEXT || it.kind == TrackKind.OVERLAY) }) {
            for (o in track.clips) {
                val overlaps = o.timelineStartUs < clip.timelineEndUs && o.timelineEndUs > clip.timelineStartUs
                if (!overlaps) continue
                when (o.kind) {
                    MediaKind.TEXT -> o.textStyle?.let { st ->
                        val span = SpannableString(st.text)
                        span.setSpan(ForegroundColorSpan(st.colorArgb.toInt()), 0, span.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        span.setSpan(AbsoluteSizeSpan(st.fontSizePx), 0, span.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        if (st.bold) span.setSpan(StyleSpan(android.graphics.Typeface.BOLD), 0, span.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        list += TextOverlay.createStaticTextOverlay(span)
                    }
                    MediaKind.IMAGE -> loadBitmap(context, o.uri)?.let { list += BitmapOverlay.createStaticBitmapOverlay(it) }
                    else -> {}
                }
            }
        }
        return list
    }

    fun loadBitmap(context: Context, uri: String): Bitmap? = runCatching {
        val src = ImageDecoder.createSource(context.contentResolver, Uri.parse(uri))
        ImageDecoder.decodeBitmap(src) { d, _, _ -> d.setTargetSampleSize(2); d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE }
    }.getOrNull()

    private fun f(v: Float) = floatArrayOf(v)
}
