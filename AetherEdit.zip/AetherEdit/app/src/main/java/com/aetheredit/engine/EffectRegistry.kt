package com.aetheredit.engine

import com.aetheredit.model.AnimatedParam
import com.aetheredit.model.EffectInstance

data class ParamSpec(
    val id: String,
    val label: String,
    val default: Float,
    val min: Float,
    val max: Float,
)

data class EffectType(
    val id: String,
    val name: String,
    val category: String,
    val params: List<ParamSpec>,
    /** GLSL ES fragment shader body. Receives uTexSampler, vTexSamplingCoord, uTexSize, uTime, and u_<param> uniforms. */
    val fragmentShader: String,
) {
    fun newInstance(): EffectInstance =
        EffectInstance(typeId = id, params = params.associate { it.id to AnimatedParam.of(it.default) })
}

/**
 * Every GPU effect available in the app. Each is a single-pass fragment shader so that it runs
 * identically in the ExoPlayer preview and in the Transformer export. Add new ones here and they
 * automatically appear in the effects panel, the inspector and the AI command vocabulary.
 */
object EffectRegistry {

    const val HEADER = """
        precision mediump float;
        uniform sampler2D uTexSampler;
        uniform vec2 uTexSize;
        uniform float uTime;
        varying vec2 vTexSamplingCoord;
    """

    private val list = mutableListOf<EffectType>()
    val all: List<EffectType> get() = list
    fun byId(id: String): EffectType? = list.firstOrNull { it.id == id }
    fun byName(name: String): EffectType? = list.firstOrNull { it.name.equals(name, true) || it.id.equals(name, true) }

    private fun register(e: EffectType) { list += e }

    init {
        register(EffectType(
            id = "color", name = "Color Correction", category = "Color",
            params = listOf(
                ParamSpec("brightness", "Brightness", 0f, -1f, 1f),
                ParamSpec("contrast", "Contrast", 1f, 0f, 3f),
                ParamSpec("saturation", "Saturation", 1f, 0f, 3f),
                ParamSpec("temperature", "Temperature", 0f, -1f, 1f),
                ParamSpec("tint", "Tint", 0f, -1f, 1f),
            ),
            fragmentShader = """
                $HEADER
                uniform float u_brightness, u_contrast, u_saturation, u_temperature, u_tint;
                void main() {
                    vec4 c = texture2D(uTexSampler, vTexSamplingCoord);
                    vec3 rgb = c.rgb + u_brightness;
                    rgb = (rgb - 0.5) * u_contrast + 0.5;
                    float l = dot(rgb, vec3(0.299, 0.587, 0.114));
                    rgb = mix(vec3(l), rgb, u_saturation);
                    rgb += vec3(u_temperature * 0.1, u_tint * 0.1, -u_temperature * 0.1);
                    gl_FragColor = vec4(clamp(rgb, 0.0, 1.0), c.a);
                }
            """
        ))

        register(EffectType(
            id = "levels", name = "Levels", category = "Color",
            params = listOf(
                ParamSpec("black", "Input Black", 0f, 0f, 1f),
                ParamSpec("white", "Input White", 1f, 0f, 1f),
                ParamSpec("gamma", "Gamma", 1f, 0.1f, 4f),
            ),
            fragmentShader = """
                $HEADER
                uniform float u_black, u_white, u_gamma;
                void main() {
                    vec4 c = texture2D(uTexSampler, vTexSamplingCoord);
                    vec3 rgb = clamp((c.rgb - u_black) / max(u_white - u_black, 0.001), 0.0, 1.0);
                    rgb = pow(rgb, vec3(1.0 / u_gamma));
                    gl_FragColor = vec4(rgb, c.a);
                }
            """
        ))

        register(EffectType(
            id = "hue", name = "Hue Shift", category = "Color",
            params = listOf(ParamSpec("hue", "Hue (deg)", 0f, -180f, 180f)),
            fragmentShader = """
                $HEADER
                uniform float u_hue;
                vec3 hueShift(vec3 color, float a) {
                    const vec3 k = vec3(0.57735);
                    float c = cos(a); float s = sin(a);
                    return color * c + cross(k, color) * s + k * dot(k, color) * (1.0 - c);
                }
                void main() {
                    vec4 c = texture2D(uTexSampler, vTexSamplingCoord);
                    gl_FragColor = vec4(clamp(hueShift(c.rgb, radians(u_hue)), 0.0, 1.0), c.a);
                }
            """
        ))

        register(EffectType(
            id = "duotone", name = "Duotone", category = "Stylize",
            params = listOf(
                ParamSpec("sr", "Shadow R", 0.05f, 0f, 1f), ParamSpec("sg", "Shadow G", 0.0f, 0f, 1f), ParamSpec("sb", "Shadow B", 0.3f, 0f, 1f),
                ParamSpec("hr", "Highlight R", 1f, 0f, 1f), ParamSpec("hg", "Highlight G", 0.85f, 0f, 1f), ParamSpec("hb", "Highlight B", 0.4f, 0f, 1f),
                ParamSpec("mix", "Mix", 1f, 0f, 1f),
            ),
            fragmentShader = """
                $HEADER
                uniform float u_sr,u_sg,u_sb,u_hr,u_hg,u_hb,u_mix;
                void main() {
                    vec4 c = texture2D(uTexSampler, vTexSamplingCoord);
                    float l = dot(c.rgb, vec3(0.299, 0.587, 0.114));
                    vec3 d = mix(vec3(u_sr,u_sg,u_sb), vec3(u_hr,u_hg,u_hb), l);
                    gl_FragColor = vec4(mix(c.rgb, d, u_mix), c.a);
                }
            """
        ))

        register(EffectType(
            id = "blur", name = "Gaussian Blur", category = "Blur & Sharpen",
            params = listOf(ParamSpec("radius", "Radius (px)", 4f, 0f, 40f)),
            fragmentShader = """
                $HEADER
                uniform float u_radius;
                void main() {
                    vec2 px = 1.0 / uTexSize;
                    float r = max(u_radius, 0.0);
                    vec4 sum = vec4(0.0); float wsum = 0.0;
                    for (int i = -6; i <= 6; i++) {
                        for (int j = -6; j <= 6; j++) {
                            vec2 o = vec2(float(i), float(j)) * px * (r / 6.0);
                            float w = exp(-(float(i*i + j*j)) / 18.0);
                            sum += texture2D(uTexSampler, vTexSamplingCoord + o) * w;
                            wsum += w;
                        }
                    }
                    gl_FragColor = sum / wsum;
                }
            """
        ))

        register(EffectType(
            id = "sharpen", name = "Sharpen", category = "Blur & Sharpen",
            params = listOf(ParamSpec("amount", "Amount", 0.5f, 0f, 3f)),
            fragmentShader = """
                $HEADER
                uniform float u_amount;
                void main() {
                    vec2 px = 1.0 / uTexSize;
                    vec4 c = texture2D(uTexSampler, vTexSamplingCoord);
                    vec4 n = texture2D(uTexSampler, vTexSamplingCoord + vec2(0.0, px.y))
                           + texture2D(uTexSampler, vTexSamplingCoord - vec2(0.0, px.y))
                           + texture2D(uTexSampler, vTexSamplingCoord + vec2(px.x, 0.0))
                           + texture2D(uTexSampler, vTexSamplingCoord - vec2(px.x, 0.0));
                    vec4 edge = c * 4.0 - n;
                    gl_FragColor = vec4(clamp(c.rgb + edge.rgb * u_amount, 0.0, 1.0), c.a);
                }
            """
        ))

        register(EffectType(
            id = "vignette", name = "Vignette", category = "Stylize",
            params = listOf(ParamSpec("amount", "Amount", 0.5f, 0f, 1f), ParamSpec("softness", "Softness", 0.5f, 0.05f, 1f)),
            fragmentShader = """
                $HEADER
                uniform float u_amount, u_softness;
                void main() {
                    vec4 c = texture2D(uTexSampler, vTexSamplingCoord);
                    vec2 d = vTexSamplingCoord - 0.5;
                    float v = smoothstep(0.8, 0.8 - u_softness, length(d) * 1.2);
                    gl_FragColor = vec4(c.rgb * mix(1.0, v, u_amount), c.a);
                }
            """
        ))

        register(EffectType(
            id = "chroma_key", name = "Chroma Key (Green Screen)", category = "Keying",
            params = listOf(
                ParamSpec("kr", "Key R", 0f, 0f, 1f), ParamSpec("kg", "Key G", 1f, 0f, 1f), ParamSpec("kb", "Key B", 0f, 0f, 1f),
                ParamSpec("similarity", "Similarity", 0.4f, 0f, 1f),
                ParamSpec("smoothness", "Smoothness", 0.1f, 0f, 1f),
                ParamSpec("spill", "Spill Suppress", 0.5f, 0f, 1f),
            ),
            fragmentShader = """
                $HEADER
                uniform float u_kr,u_kg,u_kb,u_similarity,u_smoothness,u_spill;
                vec2 uv(vec3 c){ return vec2(-0.1687*c.r-0.3313*c.g+0.5*c.b, 0.5*c.r-0.4187*c.g-0.0813*c.b); }
                void main() {
                    vec4 c = texture2D(uTexSampler, vTexSamplingCoord);
                    vec3 key = vec3(u_kr,u_kg,u_kb);
                    float d = distance(uv(c.rgb), uv(key));
                    float a = smoothstep(u_similarity * 0.5, u_similarity * 0.5 + u_smoothness * 0.5, d);
                    vec3 rgb = c.rgb;
                    float l = dot(rgb, vec3(0.299,0.587,0.114));
                    rgb = mix(rgb, mix(rgb, vec3(l), u_spill), 1.0 - a);
                    gl_FragColor = vec4(rgb * a, a);
                }
            """
        ))

        register(EffectType(
            id = "pixelate", name = "Pixelate", category = "Stylize",
            params = listOf(ParamSpec("size", "Block size", 12f, 1f, 120f)),
            fragmentShader = """
                $HEADER
                uniform float u_size;
                void main() {
                    vec2 blocks = uTexSize / max(u_size, 1.0);
                    vec2 uv = (floor(vTexSamplingCoord * blocks) + 0.5) / blocks;
                    gl_FragColor = texture2D(uTexSampler, uv);
                }
            """
        ))

        register(EffectType(
            id = "glitch", name = "Glitch", category = "Stylize",
            params = listOf(ParamSpec("amount", "Amount", 0.5f, 0f, 1f), ParamSpec("speed", "Speed", 8f, 0.5f, 30f)),
            fragmentShader = """
                $HEADER
                uniform float u_amount, u_speed;
                float rand(vec2 s){ return fract(sin(dot(s, vec2(12.9898,78.233))) * 43758.5453); }
                void main() {
                    float t = floor(uTime * u_speed);
                    float band = floor(vTexSamplingCoord.y * 24.0);
                    float r = rand(vec2(band, t));
                    float shift = (r > 1.0 - u_amount * 0.6) ? (rand(vec2(t, band)) - 0.5) * u_amount * 0.2 : 0.0;
                    vec2 uv = vTexSamplingCoord + vec2(shift, 0.0);
                    float ca = u_amount * 0.01 * (0.5 + r);
                    float rr = texture2D(uTexSampler, uv + vec2(ca, 0.0)).r;
                    float gg = texture2D(uTexSampler, uv).g;
                    float bb = texture2D(uTexSampler, uv - vec2(ca, 0.0)).b;
                    gl_FragColor = vec4(rr, gg, bb, 1.0);
                }
            """
        ))

        register(EffectType(
            id = "grain", name = "Film Grain", category = "Stylize",
            params = listOf(ParamSpec("amount", "Amount", 0.15f, 0f, 1f)),
            fragmentShader = """
                $HEADER
                uniform float u_amount;
                float rand(vec2 s){ return fract(sin(dot(s, vec2(12.9898,78.233))) * 43758.5453); }
                void main() {
                    vec4 c = texture2D(uTexSampler, vTexSamplingCoord);
                    float n = rand(vTexSamplingCoord * uTexSize + fract(uTime) * 100.0) - 0.5;
                    gl_FragColor = vec4(clamp(c.rgb + n * u_amount * 0.5, 0.0, 1.0), c.a);
                }
            """
        ))

        register(EffectType(
            id = "glow", name = "Glow", category = "Stylize",
            params = listOf(ParamSpec("threshold", "Threshold", 0.6f, 0f, 1f), ParamSpec("intensity", "Intensity", 1f, 0f, 4f), ParamSpec("radius", "Radius (px)", 8f, 1f, 40f)),
            fragmentShader = """
                $HEADER
                uniform float u_threshold, u_intensity, u_radius;
                void main() {
                    vec2 px = 1.0 / uTexSize;
                    vec4 c = texture2D(uTexSampler, vTexSamplingCoord);
                    vec3 glow = vec3(0.0); float w = 0.0;
                    for (int i = -4; i <= 4; i++) for (int j = -4; j <= 4; j++) {
                        vec3 s = texture2D(uTexSampler, vTexSamplingCoord + vec2(float(i), float(j)) * px * (u_radius / 4.0)).rgb;
                        float l = dot(s, vec3(0.299,0.587,0.114));
                        float k = exp(-float(i*i+j*j) / 8.0);
                        glow += max(s - u_threshold, 0.0) * k; w += k;
                    }
                    gl_FragColor = vec4(clamp(c.rgb + glow / w * u_intensity, 0.0, 1.0), c.a);
                }
            """
        ))

        register(EffectType(
            id = "mirror", name = "Mirror", category = "Distort",
            params = listOf(ParamSpec("axis", "Axis (0=H,1=V)", 0f, 0f, 1f)),
            fragmentShader = """
                $HEADER
                uniform float u_axis;
                void main() {
                    vec2 uv = vTexSamplingCoord;
                    if (u_axis < 0.5) { if (uv.x > 0.5) uv.x = 1.0 - uv.x; }
                    else { if (uv.y > 0.5) uv.y = 1.0 - uv.y; }
                    gl_FragColor = texture2D(uTexSampler, uv);
                }
            """
        ))

        register(EffectType(
            id = "zoom_blur", name = "Radial Zoom Blur", category = "Blur & Sharpen",
            params = listOf(ParamSpec("amount", "Amount", 0.1f, 0f, 0.5f), ParamSpec("cx", "Center X", 0.5f, 0f, 1f), ParamSpec("cy", "Center Y", 0.5f, 0f, 1f)),
            fragmentShader = """
                $HEADER
                uniform float u_amount, u_cx, u_cy;
                void main() {
                    vec2 center = vec2(u_cx, u_cy);
                    vec2 dir = (vTexSamplingCoord - center) * u_amount;
                    vec4 sum = vec4(0.0);
                    for (int i = 0; i < 12; i++) sum += texture2D(uTexSampler, vTexSamplingCoord - dir * (float(i) / 12.0));
                    gl_FragColor = sum / 12.0;
                }
            """
        ))
    }

    /** Built-in transform/opacity pass applied to every visual clip (position, scale, rotation, opacity). */
    val TRANSFORM_SHADER = """
        $HEADER
        uniform float u_posx, u_posy, u_scale, u_rotation, u_opacity;
        void main() {
            float aspect = uTexSize.x / uTexSize.y;
            vec2 uv = vTexSamplingCoord - 0.5;
            uv -= vec2(u_posx * 0.5, u_posy * 0.5);
            uv.x *= aspect;
            float a = radians(-u_rotation);
            uv = mat2(cos(a), -sin(a), sin(a), cos(a)) * uv;
            uv.x /= aspect;
            uv /= max(u_scale, 0.001);
            uv += 0.5;
            float inside = step(0.0, uv.x) * step(uv.x, 1.0) * step(0.0, uv.y) * step(uv.y, 1.0);
            vec4 c = texture2D(uTexSampler, clamp(uv, 0.0, 1.0));
            gl_FragColor = vec4(c.rgb * inside * u_opacity, c.a * inside * u_opacity);
        }
    """
}
