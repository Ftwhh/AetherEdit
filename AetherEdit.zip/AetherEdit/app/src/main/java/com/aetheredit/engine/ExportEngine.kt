package com.aetheredit.engine

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.aetheredit.model.Clip
import com.aetheredit.model.MediaKind
import com.aetheredit.model.Project
import com.aetheredit.model.Prop
import com.aetheredit.model.TrackKind
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed class ExportState {
    data class Progress(val percent: Int) : ExportState()
    data class Done(val file: File) : ExportState()
    data class Failed(val error: Throwable) : ExportState()
}

/**
 * Renders the project with Media3 Transformer (hardware encoders, H.264/AAC) applying the exact
 * same [ShaderEffect] chain used in the preview.
 *
 * Video track: all clips of the first VIDEO track become one [EditedMediaItemSequence].
 * Audio tracks: each AUDIO track becomes an additional sequence that is mixed in.
 */
@UnstableApi
object ExportEngine {

    fun export(context: Context, project: Project, outFile: File): Flow<ExportState> = callbackFlow {
        val composition = withContext(Dispatchers.Default) { buildComposition(context, project) }

        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    trySend(ExportState.Done(outFile)); close()
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    trySend(ExportState.Failed(exportException)); close()
                }
            })
            .build()

        outFile.parentFile?.mkdirs()
        transformer.start(composition, outFile.absolutePath)

        val holder = ProgressHolder()
        val poll = CoroutineScope(Dispatchers.Main).launch {
            delay(500)
            while (true) {
                val state = transformer.getProgress(holder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) trySend(ExportState.Progress(holder.progress))
                if (state == Transformer.PROGRESS_STATE_NOT_STARTED) break
                delay(250)
            }
        }
        awaitClose { poll.cancel(); runCatching { transformer.cancel() } }
    }

    fun buildComposition(context: Context, project: Project): Composition {
        val videoTrack = project.tracks.first { it.kind == TrackKind.VIDEO }
        val sequences = mutableListOf<EditedMediaItemSequence>()

        // Main video sequence
        var cursorUs = 0L
        val videoItems = videoTrack.clips.sortedBy { it.timelineStartUs }.map { clip ->
            val item = editedItem(context, project, clip, cursorUs)
            cursorUs += clip.durationUs
            item
        }
        if (videoItems.isNotEmpty()) sequences += EditedMediaItemSequence(videoItems)

        // Audio tracks (mixed into the main sequence). Media3 1.4 has no "gap" item, so clips on an
        // audio track are laid back-to-back from its first clip; a leading gap is honoured by trimming
        // nothing and starting at t=0. (Roadmap: silence padding via a generated PCM asset.)
        for (track in project.tracks.filter { it.kind == TrackKind.AUDIO && !it.muted }) {
            val items = mutableListOf<EditedMediaItem>()
            var t = 0L
            for (clip in track.clips.sortedBy { it.timelineStartUs }) {
                items += editedItem(context, project, clip, t)
                t += clip.durationUs
            }
            if (items.isNotEmpty()) sequences += EditedMediaItemSequence(items)
        }

        return Composition.Builder(sequences)
            .setTransmuxVideo(false)
            .setTransmuxAudio(false)
            .build()
    }

    private fun editedItem(context: Context, project: Project, clip: Clip, offsetUs: Long): EditedMediaItem {
        val media = MediaItem.Builder()
            .setUri(Uri.parse(clip.uri))
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(clip.inPointUs / 1000)
                    .setEndPositionMs(clip.outPointUs / 1000)
                    .build()
            )
            .build()

        val audioProcessors = mutableListOf<AudioProcessor>()
        val speed = clip.speedValue()
        if (speed != 1f) audioProcessors += SonicAudioProcessor().apply { setSpeed(speed); setPitch(1f) }
        val volume = clip.prop(Prop.VOLUME).value
        if (volume != 1f) {
            audioProcessors += ChannelMixingAudioProcessor().apply {
                putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(volume))
                putChannelMixingMatrix(ChannelMixingMatrix.create(1, 1).scaleBy(volume))
            }
        }

        val videoEffects: List<androidx.media3.common.Effect> =
            if (clip.kind == MediaKind.AUDIO) emptyList()
            else buildList {
                if (speed != 1f) add(androidx.media3.effect.SpeedChangeEffect(speed))
                addAll(EffectBuilder.forClip(context, project, clip, offsetUs))
            }

        val b = EditedMediaItem.Builder(media)
            .setEffects(Effects(ImmutableList.copyOf(audioProcessors), ImmutableList.copyOf(videoEffects)))
            .setRemoveVideo(clip.kind == MediaKind.AUDIO)
        if (clip.kind == MediaKind.IMAGE) {
            b.setDurationUs(clip.durationUs).setFrameRate(project.fps)
        }
        if (speed != 1f) {
            b.setDurationUs(clip.durationUs)
        }
        return b.build()
    }
}
