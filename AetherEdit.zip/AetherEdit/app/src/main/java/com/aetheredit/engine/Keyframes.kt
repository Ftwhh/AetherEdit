package com.aetheredit.engine

import com.aetheredit.model.AnimatedParam
import com.aetheredit.model.Easing
import com.aetheredit.model.Keyframe
import kotlin.math.abs

/**
 * Keyframe interpolation engine. Mirrors After Effects semantics:
 *  - before the first keyframe the value is held at the first keyframe's value
 *  - after the last keyframe it is held at the last keyframe's value
 *  - easing on a keyframe applies to the segment that *leaves* it
 */
object Keyframes {

    fun evaluate(param: AnimatedParam, timeUs: Long): Float {
        val kfs = param.keyframes
        if (kfs.isEmpty()) return param.value
        if (timeUs <= kfs.first().timeUs) return kfs.first().value
        if (timeUs >= kfs.last().timeUs) return kfs.last().value

        // binary search for segment
        var lo = 0
        var hi = kfs.size - 1
        while (hi - lo > 1) {
            val mid = (lo + hi) / 2
            if (kfs[mid].timeUs <= timeUs) lo = mid else hi = mid
        }
        val a = kfs[lo]
        val b = kfs[hi]
        if (a.easing == Easing.HOLD) return a.value
        val span = (b.timeUs - a.timeUs).toFloat()
        if (span <= 0f) return b.value
        val t = ((timeUs - a.timeUs) / span).coerceIn(0f, 1f)
        val eased = ease(a, t)
        return a.value + (b.value - a.value) * eased
    }

    fun ease(kf: Keyframe, t: Float): Float = when (kf.easing) {
        Easing.LINEAR -> t
        Easing.EASE_IN -> cubicBezier(0.42f, 0f, 1f, 1f, t)
        Easing.EASE_OUT -> cubicBezier(0f, 0f, 0.58f, 1f, t)
        Easing.EASE_IN_OUT -> cubicBezier(0.42f, 0f, 0.58f, 1f, t)
        Easing.HOLD -> 0f
        Easing.BEZIER -> {
            val b = kf.bezier
            if (b != null && b.size == 4) cubicBezier(b[0], b[1], b[2], b[3], t) else t
        }
    }

    /** CSS-style cubic-bezier(x1,y1,x2,y2) solved for x = t using Newton-Raphson, then bisection fallback. */
    fun cubicBezier(x1: Float, y1: Float, x2: Float, y2: Float, t: Float): Float {
        if (t <= 0f) return 0f
        if (t >= 1f) return 1f
        fun bx(u: Float) = 3f * (1 - u) * (1 - u) * u * x1 + 3f * (1 - u) * u * u * x2 + u * u * u
        fun by(u: Float) = 3f * (1 - u) * (1 - u) * u * y1 + 3f * (1 - u) * u * u * y2 + u * u * u
        fun dbx(u: Float) = 3f * (1 - u) * (1 - u) * x1 + 6f * (1 - u) * u * (x2 - x1) + 3f * u * u * (1 - x2)

        var u = t
        repeat(8) {
            val d = dbx(u)
            if (abs(d) < 1e-6f) return@repeat
            val x = bx(u) - t
            u -= x / d
            if (u < 0f) u = 0f
            if (u > 1f) u = 1f
        }
        if (abs(bx(u) - t) > 1e-4f) {
            var lo = 0f
            var hi = 1f
            repeat(30) {
                u = (lo + hi) / 2f
                if (bx(u) < t) lo = u else hi = u
            }
        }
        return by(u)
    }

    /** Returns the keyframe nearest to [timeUs] within tolerance, if any. */
    fun nearest(param: AnimatedParam, timeUs: Long, toleranceUs: Long): Keyframe? =
        param.keyframes.minByOrNull { abs(it.timeUs - timeUs) }?.takeIf { abs(it.timeUs - timeUs) <= toleranceUs }
}
