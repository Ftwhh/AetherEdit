package com.aetheredit.engine

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.aetheredit.model.Clip
import com.aetheredit.model.MediaKind
import com.aetheredit.model.Prop
import com.aetheredit.model.US_PER_SEC

/** Reads duration / type of a picked media Uri and builds a Clip for it. */
object MediaInfo {

    fun displayName(context: Context, uri: Uri): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "media"
        }
        return uri.lastPathSegment ?: "media"
    }

    fun kindOf(context: Context, uri: Uri): MediaKind {
        val mime = context.contentResolver.getType(uri) ?: ""
        return when {
            mime.startsWith("video") -> MediaKind.VIDEO
            mime.startsWith("image") -> MediaKind.IMAGE
            mime.startsWith("audio") -> MediaKind.AUDIO
            else -> MediaKind.VIDEO
        }
    }

    fun durationUs(context: Context, uri: Uri): Long = runCatching {
        MediaMetadataRetriever().use { r ->
            r.setDataSource(context, uri)
            (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000L
        }
    }.getOrDefault(0L)

    fun clipFor(context: Context, uri: Uri, timelineStartUs: Long): Clip {
        val kind = kindOf(context, uri)
        val dur = if (kind == MediaKind.IMAGE) 5 * US_PER_SEC else durationUs(context, uri)
        return Clip(
            name = displayName(context, uri),
            uri = uri.toString(),
            kind = kind,
            timelineStartUs = timelineStartUs,
            inPointUs = 0L,
            outPointUs = dur,
            sourceDurationUs = if (kind == MediaKind.IMAGE) Long.MAX_VALUE / 4 else dur,
            props = Prop.defaults,
        )
    }
}
