package com.aetheredit.engine

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.aetheredit.model.Clip
import com.aetheredit.model.Project
import com.aetheredit.model.TrackKind

/**
 * Real-time preview. Plays the main video track as an ExoPlayer playlist and applies the
 * current clip's keyframed [ShaderEffect] chain through `setVideoEffects`, so the preview matches
 * the export frame-for-frame.
 *
 * Parameter/keyframe edits are read live by the shaders (no pipeline rebuild). Structural edits
 * (effect added/removed, overlays changed) rebuild the chain for the current item.
 */
@UnstableApi
class PreviewEngine(private val context: Context) {

    val player: ExoPlayer = ExoPlayer.Builder(context).build().apply {
        playWhenReady = false
        repeatMode = Player.REPEAT_MODE_OFF
    }

    @Volatile private var project: Project = Project()
    @Volatile private var orderedClips: List<Clip> = emptyList()
    private var clipStarts: List<Long> = emptyList()
    private var appliedSignature: String? = null

    init {
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { applyEffects(force = true) }
        })
    }

    private fun index(project: Project) {
        this.project = project
        val track = project.tracks.firstOrNull { it.kind == TrackKind.VIDEO }
        orderedClips = track?.clips?.sortedBy { it.timelineStartUs } ?: emptyList()
        var t = 0L
        clipStarts = orderedClips.map { c -> t.also { t += c.durationUs } }
    }

    /** Rebuilds the playlist from the project. Call whenever clips change. */
    fun load(project: Project, keepPosition: Boolean = true) {
        val pos = if (keepPosition) timelinePositionUs() else 0L
        val wasPlaying = player.isPlaying
        index(project)
        player.setMediaItems(orderedClips.map { c ->
            MediaItem.Builder()
                .setUri(Uri.parse(c.uri))
                .setMediaId(c.id)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.inPointUs / 1000)
                        .setEndPositionMs(c.outPointUs / 1000)
                        .build()
                ).build()
        })
        appliedSignature = null
        seekTo(pos)
        applyEffects(force = true)
        player.prepare()
        player.playWhenReady = wasPlaying
    }

    /** Parameter / effect-list edits without clip changes. */
    fun refreshEffects(project: Project) {
        index(project)
        applyEffects(force = false)
    }

    private fun currentClip(): Clip? {
        val idx = player.currentMediaItemIndex
        return orderedClips.getOrNull(idx)
    }

    private fun applyEffects(force: Boolean) {
        val clip = currentClip() ?: return
        val sig = EffectBuilder.chainSignature(project, clip)
        if (!force && sig == appliedSignature) return   // shaders read live values; nothing to rebuild
        appliedSignature = sig
        val id = clip.id
        player.setPlaybackSpeed(clip.speedValue())
        // Presentation times inside ExoPlayer's effect pipeline are relative to the stream (clip in-point).
        player.setVideoEffects(EffectBuilder.forClip(context, project, clip, clip.inPointUs) {
            orderedClips.firstOrNull { it.id == id } ?: clip
        })
        if (!force && player.playbackState != Player.STATE_IDLE) {
            // ExoPlayer applies a new effect list on the next stream start: re-prepare in place.
            val idx = player.currentMediaItemIndex; val pos = player.currentPosition; val playing = player.playWhenReady
            player.stop(); player.prepare(); player.seekTo(idx, pos); player.playWhenReady = playing
        }
    }

    fun seekTo(timelineUs: Long) {
        if (orderedClips.isEmpty()) return
        var idx = clipStarts.indexOfLast { it <= timelineUs }.coerceAtLeast(0)
        if (idx >= orderedClips.size) idx = orderedClips.size - 1
        val inClip = (timelineUs - clipStarts[idx]).coerceIn(0, orderedClips[idx].durationUs)
        player.seekTo(idx, (inClip * orderedClips[idx].speedValue()).toLong() / 1000)
    }

    fun timelinePositionUs(): Long {
        val idx = player.currentMediaItemIndex
        if (idx < 0 || idx >= orderedClips.size) return 0L
        val base = clipStarts.getOrElse(idx) { 0L }
        val local = (player.currentPosition * 1000) / orderedClips[idx].speedValue()
        return base + local.toLong()
    }

    fun play() { player.play() }
    fun pause() { player.pause() }
    fun togglePlay() { if (player.isPlaying) pause() else play() }
    fun release() { player.release() }
}
