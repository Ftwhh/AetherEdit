package com.aetheredit.engine

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/**
 * A Media3 [GlEffect] driven by one fragment shader whose uniforms are evaluated per frame from
 * the presentation timestamp. This is what lets every effect parameter be keyframed: the
 * [uniformsAt] lambda calls [Keyframes.evaluate] for the frame time.
 *
 * The same class is used by the ExoPlayer preview and by the Transformer export, so what you see
 * is what you render.
 */
@UnstableApi
class ShaderEffect(
    private val fragmentShader: String,
    /** Called once per frame; returns uniform name -> value (1 float, vec2, vec3 or vec4). */
    private val uniformsAt: (presentationTimeUs: Long) -> Map<String, FloatArray>,
    /** Offset subtracted from presentation time so keyframes are clip-relative. */
    private val timeOffsetUs: Long = 0L,
) : GlEffect {

    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        Program(useHdr, fragmentShader, uniformsAt, timeOffsetUs)

    private class Program(
        useHdr: Boolean,
        fragmentShader: String,
        private val uniformsAt: (Long) -> Map<String, FloatArray>,
        private val timeOffsetUs: Long,
    ) : BaseGlShaderProgram(useHdr, /* texturePoolCapacity= */ 1) {

        private val glProgram: GlProgram
        private var width = 0
        private var height = 0

        init {
            try {
                glProgram = GlProgram(VERTEX_SHADER, fragmentShader)
            } catch (e: GlUtil.GlException) {
                throw VideoFrameProcessingException(e)
            }
            glProgram.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE,
            )
        }

        override fun configure(inputWidth: Int, inputHeight: Int): Size {
            width = inputWidth
            height = inputHeight
            return Size(inputWidth, inputHeight)
        }

        override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
            try {
                glProgram.use()
                glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
                glProgram.setFloatsUniform("uTexSize", floatArrayOf(width.toFloat(), height.toFloat()))
                val localUs = presentationTimeUs - timeOffsetUs
                glProgram.setFloatUniform("uTime", (localUs / 1_000_000.0).toFloat())
                for ((name, v) in uniformsAt(localUs)) {
                    if (v.size == 1) glProgram.setFloatUniform(name, v[0]) else glProgram.setFloatsUniform(name, v)
                }
                glProgram.bindAttributesAndUniforms()
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
                GlUtil.checkGlError()
            } catch (e: GlUtil.GlException) {
                throw VideoFrameProcessingException(e, presentationTimeUs)
            }
        }

        override fun release() {
            super.release()
            try { glProgram.delete() } catch (e: GlUtil.GlException) { throw VideoFrameProcessingException(e) }
        }
    }

    companion object {
        const val VERTEX_SHADER = """
            attribute vec4 aFramePosition;
            varying vec2 vTexSamplingCoord;
            void main() {
                gl_Position = aFramePosition;
                vTexSamplingCoord = vec2(aFramePosition.x * 0.5 + 0.5, aFramePosition.y * 0.5 + 0.5);
            }
        """
    }
}
