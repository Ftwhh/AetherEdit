package com.aetheredit.model

import kotlinx.serialization.Serializable
import java.util.UUID

/** Microsecond helpers. */
const val US_PER_SEC = 1_000_000L
fun Long.usToSec(): Double = this / 1_000_000.0
fun Double.secToUs(): Long = (this * 1_000_000L).toLong()

@Serializable
enum class TrackKind { VIDEO, AUDIO, TEXT, OVERLAY }

@Serializable
enum class MediaKind { VIDEO, IMAGE, AUDIO, TEXT }

@Serializable
enum class Easing { LINEAR, EASE_IN, EASE_OUT, EASE_IN_OUT, HOLD, BEZIER }

/**
 * One keyframe. [bezier] = [x1, y1, x2, y2] control points (CSS cubic-bezier style),
 * only used when easing == BEZIER. Easing describes the segment *leaving* this keyframe.
 */
@Serializable
data class Keyframe(
    val timeUs: Long,
    val value: Float,
    val easing: Easing = Easing.EASE_IN_OUT,
    val bezier: List<Float>? = null,
)

/** A float property that can be static or animated. Times are relative to the clip start on the timeline. */
@Serializable
data class AnimatedParam(
    val value: Float,
    val keyframes: List<Keyframe> = emptyList(),
) {
    val isAnimated: Boolean get() = keyframes.isNotEmpty()

    fun withKeyframe(kf: Keyframe): AnimatedParam {
        val others = keyframes.filterNot { kotlin.math.abs(it.timeUs - kf.timeUs) < 1_000 }
        return copy(keyframes = (others + kf).sortedBy { it.timeUs })
    }

    fun removeKeyframeAt(timeUs: Long, toleranceUs: Long = 16_000): AnimatedParam =
        copy(keyframes = keyframes.filterNot { kotlin.math.abs(it.timeUs - timeUs) <= toleranceUs })

    companion object {
        fun of(v: Float) = AnimatedParam(v)
    }
}

/** An instance of an effect from [com.aetheredit.engine.EffectRegistry] attached to a clip. */
@Serializable
data class EffectInstance(
    val id: String = UUID.randomUUID().toString(),
    val typeId: String,
    val enabled: Boolean = true,
    val params: Map<String, AnimatedParam> = emptyMap(),
)

/** Standard transform properties every visual clip has (After-Effects style). */
object Prop {
    const val POS_X = "position.x"       // -1..1 (normalized, 0 = center)
    const val POS_Y = "position.y"
    const val SCALE = "scale"            // 1 = 100%
    const val ROTATION = "rotation"      // degrees
    const val OPACITY = "opacity"        // 0..1
    const val VOLUME = "volume"          // 0..2
    const val SPEED = "speed"            // playback rate

    val defaults: Map<String, AnimatedParam> = mapOf(
        POS_X to AnimatedParam.of(0f),
        POS_Y to AnimatedParam.of(0f),
        SCALE to AnimatedParam.of(1f),
        ROTATION to AnimatedParam.of(0f),
        OPACITY to AnimatedParam.of(1f),
        VOLUME to AnimatedParam.of(1f),
        SPEED to AnimatedParam.of(1f),
    )
}

@Serializable
data class TextStyle(
    val text: String = "Title",
    val fontSizePx: Int = 96,
    val colorArgb: Long = 0xFFFFFFFF,
    val bold: Boolean = true,
)

@Serializable
data class Clip(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val uri: String,                 // content:// or file:// ; empty for TEXT clips
    val kind: MediaKind,
    val timelineStartUs: Long,       // where the clip sits on the timeline
    val inPointUs: Long = 0L,        // trim in, relative to source
    val outPointUs: Long,            // trim out, relative to source (for images: duration)
    val sourceDurationUs: Long,      // full source length (images: Long.MAX_VALUE / unbounded)
    val props: Map<String, AnimatedParam> = Prop.defaults,
    val effects: List<EffectInstance> = emptyList(),
    val textStyle: TextStyle? = null,
) {
    val durationUs: Long get() = ((outPointUs - inPointUs) / speedValue()).toLong()
    val timelineEndUs: Long get() = timelineStartUs + durationUs

    fun speedValue(): Float = props[Prop.SPEED]?.value?.coerceIn(0.1f, 8f) ?: 1f

    fun prop(key: String): AnimatedParam = props[key] ?: Prop.defaults[key] ?: AnimatedParam.of(0f)
    fun withProp(key: String, p: AnimatedParam) = copy(props = props + (key to p))
}

@Serializable
data class Track(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: TrackKind,
    val clips: List<Clip> = emptyList(),
    val muted: Boolean = false,
    val locked: Boolean = false,
    val visible: Boolean = true,
) {
    val endUs: Long get() = clips.maxOfOrNull { it.timelineEndUs } ?: 0L
}

@Serializable
data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Untitled",
    val width: Int = 1080,
    val height: Int = 1920,
    val fps: Int = 30,
    val tracks: List<Track> = listOf(
        Track(name = "Video 1", kind = TrackKind.VIDEO),
        Track(name = "Overlay 1", kind = TrackKind.OVERLAY),
        Track(name = "Text 1", kind = TrackKind.TEXT),
        Track(name = "Audio 1", kind = TrackKind.AUDIO),
    ),
) {
    val durationUs: Long get() = tracks.maxOfOrNull { it.endUs } ?: 0L

    fun findClip(id: String): Pair<Track, Clip>? {
        for (t in tracks) t.clips.firstOrNull { it.id == id }?.let { return t to it }
        return null
    }

    fun updateClip(clipId: String, f: (Clip) -> Clip): Project = copy(
        tracks = tracks.map { t -> t.copy(clips = t.clips.map { if (it.id == clipId) f(it) else it }) }
    )

    fun removeClip(clipId: String): Project = copy(
        tracks = tracks.map { t -> t.copy(clips = t.clips.filterNot { it.id == clipId }) }
    )

    fun addClip(trackId: String, clip: Clip): Project = copy(
        tracks = tracks.map { t -> if (t.id == trackId) t.copy(clips = (t.clips + clip).sortedBy { it.timelineStartUs }) else t }
    )

    /** Clips under the playhead on the main video track, in track order. */
    fun clipsAt(timeUs: Long): List<Pair<Track, Clip>> =
        tracks.flatMap { t -> t.clips.filter { timeUs >= it.timelineStartUs && timeUs < it.timelineEndUs }.map { t to it } }
}
