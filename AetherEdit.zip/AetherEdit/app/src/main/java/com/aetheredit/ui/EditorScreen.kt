package com.aetheredit.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.aetheredit.model.usToSec
import com.aetheredit.ui.theme.Accent
import com.aetheredit.ui.theme.Ink
import com.aetheredit.ui.theme.Panel as PanelColor
import com.aetheredit.ui.theme.TextDim
import com.aetheredit.viewmodel.EditorViewModel
import com.aetheredit.viewmodel.Panel
import kotlinx.coroutines.delay

@UnstableApi
@Composable
fun EditorScreen(vm: EditorViewModel) {
    val ui by vm.ui.collectAsState()

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> vm.importMedia(uris) }

    LaunchedEffect(ui.toast) { if (ui.toast != null) { delay(2500); vm.toast(null) } }

    Column(Modifier.fillMaxSize().background(Ink).safeDrawingPadding()) {
        // ---- top bar ----
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(ui.project.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f).padding(start = 8.dp))
            IconButton(onClick = vm::undo, enabled = vm.canUndo) { Icon(Icons.Default.Undo, "Undo") }
            IconButton(onClick = vm::redo, enabled = vm.canRedo) { Icon(Icons.Default.Redo, "Redo") }
            IconButton(onClick = { pickMedia.launch(arrayOf("video/*", "image/*", "audio/*")) }) { Icon(Icons.Default.AddPhotoAlternate, "Import") }
        }

        // ---- preview ----
        Box(
            Modifier.fillMaxWidth().weight(1f).background(Color.Black),
            contentAlignment = Alignment.Center,
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = vm.preview.player
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                    }
                },
                modifier = Modifier.fillMaxHeight().aspectRatio(ui.project.width.toFloat() / ui.project.height),
            )
            if (ui.project.tracks.all { it.clips.isEmpty() }) {
                Text("Tap + to import video, photos or music", color = TextDim)
            }
        }

        // ---- transport ----
        Row(Modifier.fillMaxWidth().background(PanelColor).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = vm::togglePlay) { Icon(if (ui.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play") }
            Text(
                "${fmt(ui.playheadUs.usToSec())} / ${fmt(ui.project.durationUs.usToSec())}",
                fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = TextDim,
            )
            Spacer(Modifier.weight(1f))
            IconButton(onClick = vm::splitAtPlayhead, enabled = ui.selectedClipId != null) { Icon(Icons.Default.ContentCut, "Split") }
            IconButton(onClick = { vm.addTextClip("Title") }) { Icon(Icons.Default.TextFields, "Add text") }
            IconButton(onClick = vm::deleteSelected, enabled = ui.selectedClipId != null) { Icon(Icons.Default.Delete, "Delete") }
        }

        // ---- timeline ----
        Timeline(
            ui = ui,
            onSeek = vm::seek,
            onSelect = vm::select,
            onMove = vm::moveClip,
            onTrim = vm::trimClip,
            onZoom = vm::setZoom,
            modifier = Modifier.fillMaxWidth().height(170.dp),
        )

        // ---- bottom panel ----
        Box(Modifier.fillMaxWidth().height(250.dp).background(PanelColor)) {
            when (ui.panel) {
                Panel.CLIPS -> ClipsPanel(ui, vm)
                Panel.INSPECTOR -> InspectorPanel(ui, vm)
                Panel.EFFECTS -> EffectsPanel(ui, vm)
                Panel.AI -> AiPanel(ui, vm)
                Panel.EXPORT -> ExportPanel(ui, vm)
            }
            ui.toast?.let { Snackbar(Modifier.align(Alignment.BottomCenter).padding(8.dp)) { Text(it) } }
        }

        NavigationBar(containerColor = Ink, tonalElevation = 0.dp) {
            NavigationBarItem(ui.panel == Panel.CLIPS, { vm.setPanel(Panel.CLIPS) }, { Icon(Icons.Default.VideoLibrary, null) }, label = { Text("Clips") })
            NavigationBarItem(ui.panel == Panel.INSPECTOR, { vm.setPanel(Panel.INSPECTOR) }, { Icon(Icons.Default.Tune, null) }, label = { Text("Inspect") })
            NavigationBarItem(ui.panel == Panel.EFFECTS, { vm.setPanel(Panel.EFFECTS) }, { Icon(Icons.Default.AutoAwesome, null) }, label = { Text("Effects") })
            NavigationBarItem(ui.panel == Panel.AI, { vm.setPanel(Panel.AI) }, { Icon(Icons.Default.AutoAwesome, null, tint = Accent) }, label = { Text("AI") })
            NavigationBarItem(ui.panel == Panel.EXPORT, { vm.setPanel(Panel.EXPORT) }, { Icon(Icons.Default.FileUpload, null) }, label = { Text("Export") })
        }
    }
}

fun fmt(sec: Double): String {
    val m = (sec / 60).toInt(); val s = sec - m * 60
    return "%d:%05.2f".format(m, s)
}
