package com.aetheredit.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.media3.common.util.UnstableApi
import com.aetheredit.ai.AiBackend
import com.aetheredit.engine.EffectRegistry
import com.aetheredit.engine.ExportState
import com.aetheredit.engine.Keyframes
import com.aetheredit.model.AnimatedParam
import com.aetheredit.model.Easing
import com.aetheredit.model.Prop
import com.aetheredit.model.usToSec
import com.aetheredit.ui.theme.Accent
import com.aetheredit.ui.theme.KeyframeGold
import com.aetheredit.ui.theme.PanelHi
import com.aetheredit.ui.theme.TextDim
import com.aetheredit.viewmodel.EditorUiState
import com.aetheredit.viewmodel.EditorViewModel
import com.aetheredit.viewmodel.Panel

// ---------------- Clips ----------------
@UnstableApi
@Composable
fun ClipsPanel(ui: EditorUiState, vm: EditorViewModel) {
    LazyColumn(Modifier.fillMaxSize().padding(8.dp)) {
        ui.project.tracks.forEach { t ->
            item { Text(t.name, color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)) }
            items(t.clips, key = { it.id }) { c ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 2.dp)
                        .background(if (c.id == ui.selectedClipId) PanelHi else Color.Transparent, RoundedCornerShape(8.dp))
                        .clickable { vm.select(c.id); vm.seek(c.timelineStartUs) }.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(c.name, Modifier.weight(1f), maxLines = 1)
                    Text("${fmt(c.timelineStartUs.usToSec())}  ·  ${"%.1fs".format(c.durationUs.usToSec())}", color = TextDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)); TextButton(onClick = vm::duplicateSelected, enabled = ui.selectedClipId != null) { Text("Duplicate selected") } }
    }
}

// ---------------- Inspector ----------------
@UnstableApi
@Composable
fun InspectorPanel(ui: EditorUiState, vm: EditorViewModel) {
    val clip = ui.selectedClip
    if (clip == null) { Center("Select a clip on the timeline"); return }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp)) {
        Text(clip.name, style = MaterialTheme.typography.titleSmall)
        Text("local time ${fmt(vm.selectedLocalTimeUs().usToSec())}", color = TextDim, fontSize = 11.sp)

        Section("Transform")
        PropRow("Position X", clip.prop(Prop.POS_X), -1f, 1f, vm.currentValue(Prop.POS_X), vm, Prop.POS_X, null)
        PropRow("Position Y", clip.prop(Prop.POS_Y), -1f, 1f, vm.currentValue(Prop.POS_Y), vm, Prop.POS_Y, null)
        PropRow("Scale", clip.prop(Prop.SCALE), 0f, 4f, vm.currentValue(Prop.SCALE), vm, Prop.SCALE, null)
        PropRow("Rotation", clip.prop(Prop.ROTATION), -360f, 360f, vm.currentValue(Prop.ROTATION), vm, Prop.ROTATION, null)
        PropRow("Opacity", clip.prop(Prop.OPACITY), 0f, 1f, vm.currentValue(Prop.OPACITY), vm, Prop.OPACITY, null)
        Section("Audio & time")
        PropRow("Volume", clip.prop(Prop.VOLUME), 0f, 2f, clip.prop(Prop.VOLUME).value, vm, Prop.VOLUME, null, keyframable = false)
        PropRow("Speed", clip.prop(Prop.SPEED), 0.25f, 4f, clip.prop(Prop.SPEED).value, vm, Prop.SPEED, null, keyframable = false)

        if (clip.effects.isNotEmpty()) Section("Effects")
        clip.effects.forEach { e ->
            val type = EffectRegistry.byId(e.typeId) ?: return@forEach
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.toggleEffect(e.id) }, Modifier.size(28.dp)) { Icon(if (e.enabled) Icons.Default.Visibility else Icons.Default.VisibilityOff, null, Modifier.size(16.dp)) }
                Text(type.name, Modifier.weight(1f).padding(start = 4.dp), style = MaterialTheme.typography.labelLarge)
                IconButton(onClick = { vm.moveEffect(e.id, -1) }, Modifier.size(28.dp)) { Icon(Icons.Default.ArrowUpward, null, Modifier.size(16.dp)) }
                IconButton(onClick = { vm.moveEffect(e.id, 1) }, Modifier.size(28.dp)) { Icon(Icons.Default.ArrowDownward, null, Modifier.size(16.dp)) }
                IconButton(onClick = { vm.removeEffect(e.id) }, Modifier.size(28.dp)) { Icon(Icons.Default.Close, null, Modifier.size(16.dp)) }
            }
            type.params.forEach { spec ->
                val p = e.params[spec.id] ?: AnimatedParam.of(spec.default)
                PropRow(spec.label, p, spec.min, spec.max, vm.currentEffectValue(e, spec.id), vm, spec.id, e.id)
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable private fun Section(t: String) = Text(t, color = Accent, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 2.dp))

@Composable private fun Center(t: String) = Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(t, color = TextDim) }

/** A slider row with an After-Effects-style stopwatch (keyframe) toggle and easing chips. */
@UnstableApi
@Composable
private fun PropRow(
    label: String, param: AnimatedParam, min: Float, max: Float, value: Float,
    vm: EditorViewModel, prop: String, effectId: String?, keyframable: Boolean = true,
) {
    val t = vm.selectedLocalTimeUs()
    val onKf = Keyframes.nearest(param, t, 16_000)
    var showEase by remember(prop, effectId) { mutableStateOf(false) }
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (keyframable) IconButton(onClick = { vm.toggleKeyframe(prop, effectId) }, Modifier.size(28.dp)) {
                Icon(
                    if (onKf != null) Icons.Default.Circle else Icons.Outlined.Circle, "Keyframe",
                    tint = if (param.isAnimated) KeyframeGold else TextDim, modifier = Modifier.size(14.dp),
                )
            } else Spacer(Modifier.width(28.dp))
            Text(label, Modifier.width(92.dp), fontSize = 12.sp, maxLines = 1)
            Slider(
                value = value.coerceIn(min, max), onValueChange = { v -> if (effectId == null) vm.setProp(prop, v, false) else vm.setEffectParam(effectId, prop, v, false) },
                onValueChangeFinished = { if (effectId == null) vm.setProp(prop, value, true) else vm.setEffectParam(effectId, prop, value, true) },
                valueRange = min..max, modifier = Modifier.weight(1f),
            )
            Text("%.2f".format(value), Modifier.width(44.dp).clickable { if (param.isAnimated) showEase = !showEase }, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = if (param.isAnimated) KeyframeGold else TextDim)
        }
        if (param.isAnimated && (showEase || onKf != null)) {
            LazyRow(Modifier.padding(start = 28.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                items(Easing.entries.filter { it != Easing.BEZIER }) { e ->
                    FilterChip(selected = onKf?.easing == e, onClick = { vm.setKeyframeEasing(prop, effectId, e) }, label = { Text(e.name.lowercase().replace('_', ' '), fontSize = 10.sp) })
                }
                item { AssistChip(onClick = { vm.clearAnimation(prop, effectId) }, label = { Text("clear", fontSize = 10.sp) }) }
            }
        }
    }
}

// ---------------- Effects browser ----------------
@UnstableApi
@Composable
fun EffectsPanel(ui: EditorUiState, vm: EditorViewModel) {
    if (ui.selectedClipId == null) { Center("Select a clip, then tap an effect to add it"); return }
    val cats = EffectRegistry.all.groupBy { it.category }
    LazyColumn(Modifier.fillMaxSize().padding(8.dp)) {
        cats.forEach { (cat, list) ->
            item { Text(cat, color = Accent, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list) { e ->
                        Box(
                            Modifier.width(110.dp).height(56.dp).background(PanelHi, RoundedCornerShape(10.dp)).clickable { vm.addEffect(e.id) }.padding(8.dp),
                            contentAlignment = Alignment.CenterStart,
                        ) { Text(e.name, fontSize = 12.sp, maxLines = 2) }
                    }
                }
            }
        }
    }
}

// ---------------- AI ----------------
@UnstableApi
@Composable
fun AiPanel(ui: EditorUiState, vm: EditorViewModel) {
    var text by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    val suggestions = listOf("fade in over 1 second", "make it cinematic", "slow motion", "zoom in slowly", "add subtitles", "remove background", "black and white", "add glitch")

    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("AI · ${vm.aiSettings.provider().name}", color = TextDim, fontSize = 11.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = { showSettings = !showSettings }) { Text("Brain settings", fontSize = 11.sp) }
        }
        if (showSettings) AiSettingsCard(vm)
        LazyColumn(Modifier.weight(1f)) {
            items(ui.aiLog) { Text(it, fontSize = 12.sp, color = if (it.startsWith("›")) Color.White else TextDim, modifier = Modifier.padding(vertical = 1.dp)) }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(suggestions) { s -> AssistChip(onClick = { vm.runAi(s) }, label = { Text(s, fontSize = 11.sp) }) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Tell the editor what to do…", fontSize = 13.sp) }, singleLine = true, enabled = !ui.aiBusy,
            )
            IconButton(onClick = { if (text.isNotBlank()) { vm.runAi(text); text = "" } }, enabled = !ui.aiBusy) { Icon(Icons.Default.Send, "Run", tint = Accent) }
        }
        if (ui.aiBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
    }
}

@UnstableApi
@Composable
private fun AiSettingsCard(vm: EditorViewModel) {
    val s = vm.aiSettings
    var backend by remember { mutableStateOf(s.backend) }
    var key by remember { mutableStateOf(s.apiKey) }
    var url by remember { mutableStateOf(s.customBaseUrl) }
    var model by remember { mutableStateOf(s.customModel) }
    Column(Modifier.fillMaxWidth().background(PanelHi, RoundedCornerShape(10.dp)).padding(8.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(AiBackend.entries) { b ->
                FilterChip(selected = backend == b, onClick = { backend = b; s.backend = b }, label = {
                    Text(when (b) { AiBackend.OFFLINE -> "Offline (no key)"; AiBackend.GROQ -> "Groq free"; AiBackend.GEMINI -> "Gemini free"; AiBackend.CUSTOM_OPENAI -> "Local / custom" }, fontSize = 11.sp)
                })
            }
        }
        if (backend != AiBackend.OFFLINE) OutlinedTextField(key, { key = it; s.apiKey = it }, Modifier.fillMaxWidth(), label = { Text("API key (free tier)") }, singleLine = true)
        if (backend == AiBackend.CUSTOM_OPENAI) {
            OutlinedTextField(url, { url = it; s.customBaseUrl = it }, Modifier.fillMaxWidth(), label = { Text("Base URL (OpenAI-compatible, e.g. Ollama)") }, singleLine = true)
            OutlinedTextField(model, { model = it; s.customModel = it }, Modifier.fillMaxWidth(), label = { Text("Model") }, singleLine = true)
        }
        Text("Offline rules always work without internet. Online brains fall back to offline automatically.", color = TextDim, fontSize = 10.sp)
    }
}

// ---------------- Export ----------------
@UnstableApi
@Composable
fun ExportPanel(ui: EditorUiState, vm: EditorViewModel) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Aspect ratio", color = TextDim, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("9:16" to (1080 to 1920), "16:9" to (1920 to 1080), "1:1" to (1080 to 1080), "4:5" to (1080 to 1350)).forEach { (l, wh) ->
                FilterChip(selected = ui.project.width == wh.first && ui.project.height == wh.second, onClick = { vm.setAspect(wh.first, wh.second) }, label = { Text(l) })
            }
        }
        when (val st = ui.export) {
            null -> Button(onClick = vm::export, enabled = ui.project.durationUs > 0) { Text("Export MP4 (H.264 / AAC)") }
            is ExportState.Progress -> { Text("Rendering… ${st.percent}%"); LinearProgressIndicator(progress = { st.percent / 100f }, Modifier.fillMaxWidth()) }
            is ExportState.Done -> {
                Text("Done: ${st.file.name}", color = Color(0xFF7CE38B))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", st.file)
                        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "Share video"))
                    }) { Text("Share / Save") }
                    TextButton(onClick = vm::clearExport) { Text("New export") }
                }
            }
            is ExportState.Failed -> { Text("Export failed: ${st.error.message}", color = Color(0xFFFF7B7B)); TextButton(onClick = vm::clearExport) { Text("Retry") } }
        }
        Text("Exports use the phone's hardware encoder and apply the same GPU shader chain as the preview.", color = TextDim, fontSize = 11.sp)
    }
}
