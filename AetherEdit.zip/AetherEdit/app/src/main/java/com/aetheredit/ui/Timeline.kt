package com.aetheredit.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import com.aetheredit.model.Clip
import com.aetheredit.model.MediaKind
import com.aetheredit.model.TrackKind
import com.aetheredit.model.US_PER_SEC
import com.aetheredit.ui.theme.Accent
import com.aetheredit.ui.theme.ClipAudio
import com.aetheredit.ui.theme.ClipOverlay
import com.aetheredit.ui.theme.ClipText
import com.aetheredit.ui.theme.ClipVideo
import com.aetheredit.ui.theme.Ink
import com.aetheredit.ui.theme.KeyframeGold
import com.aetheredit.ui.theme.PanelHi
import com.aetheredit.viewmodel.EditorUiState
import kotlin.math.abs
import kotlin.math.roundToLong

private const val RULER_H = 22f
private const val HEADER_W = 0f
private const val EDGE_PX = 28f

private sealed class Drag {
    data object Scrub : Drag()
    data object Pan : Drag()
    data class Move(val clip: Clip, val startUs: Long) : Drag()
    data class TrimIn(val clip: Clip) : Drag()
    data class TrimOut(val clip: Clip) : Drag()
}

/**
 * Multi-track timeline drawn on a Canvas. Gestures:
 *  tap clip = select, tap ruler/empty = seek, drag ruler = scrub, drag clip = move,
 *  drag clip edge = trim, pinch = zoom, two-finger/empty drag = pan.
 */
@Composable
fun Timeline(
    ui: EditorUiState,
    onSeek: (Long) -> Unit,
    onSelect: (String?) -> Unit,
    onMove: (clipId: String, newStartUs: Long, commit: Boolean) -> Unit,
    onTrim: (clipId: String, inUs: Long, outUs: Long, commit: Boolean) -> Unit,
    onZoom: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    var scrollPx by remember { mutableFloatStateOf(0f) }
    var drag by remember { mutableStateOf<Drag?>(null) }
    var dragAccum by remember { mutableFloatStateOf(0f) }
    val pps = ui.pixelsPerSecond * density.density
    val trackH = with(density) { 34.dp.toPx() }
    val labelPaint = remember {
        android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = 11 * density.density; isAntiAlias = true }
    }
    val tracks = ui.project.tracks

    fun xToUs(x: Float): Long = (((x + scrollPx) / pps) * US_PER_SEC).roundToLong().coerceAtLeast(0)
    fun usToX(us: Long): Float = us / US_PER_SEC.toFloat() * pps - scrollPx
    fun trackAt(y: Float): Int = ((y - RULER_H) / trackH).toInt()
    fun hit(x: Float, y: Float): Pair<Clip, Int>? {
        val ti = trackAt(y); if (ti !in tracks.indices) return null
        val us = xToUs(x)
        val c = tracks[ti].clips.firstOrNull { us >= it.timelineStartUs && us < it.timelineEndUs } ?: return null
        return c to ti
    }

    Canvas(
        modifier
            .background(Ink)
            .pointerInput(ui.project, pps) {
                detectTapGestures { p ->
                    if (p.y < RULER_H) { onSeek(xToUs(p.x)); return@detectTapGestures }
                    val h = hit(p.x, p.y)
                    if (h != null) onSelect(h.first.id) else { onSelect(null); onSeek(xToUs(p.x)) }
                }
            }
            .pointerInput(ui.project, pps) {
                detectTransformGestures(panZoomLock = false) { centroid, pan, zoom, _ ->
                    if (zoom != 1f) { onZoom(ui.pixelsPerSecond * zoom); drag = Drag.Pan; return@detectTransformGestures }
                    if (drag == null) {
                        dragAccum = 0f
                        drag = when {
                            centroid.y < RULER_H -> Drag.Scrub
                            else -> {
                                val h = hit(centroid.x, centroid.y)
                                if (h == null) Drag.Pan else {
                                    val c = h.first
                                    val xs = usToX(c.timelineStartUs); val xe = usToX(c.timelineEndUs)
                                    when {
                                        abs(centroid.x - xs) < EDGE_PX -> Drag.TrimIn(c)
                                        abs(centroid.x - xe) < EDGE_PX -> Drag.TrimOut(c)
                                        else -> Drag.Move(c, c.timelineStartUs)
                                    }
                                }
                            }
                        }
                    }
                    dragAccum += pan.x
                    val dUs = (dragAccum / pps * US_PER_SEC).roundToLong()
                    when (val d = drag) {
                        Drag.Scrub -> onSeek(xToUs(centroid.x))
                        Drag.Pan -> scrollPx = (scrollPx - pan.x).coerceAtLeast(0f)
                        is Drag.Move -> onMove(d.clip.id, d.startUs + dUs, false)
                        is Drag.TrimIn -> {
                            val c = d.clip
                            val newIn = c.inPointUs + (dUs * c.speedValue()).toLong()
                            onTrim(c.id, newIn, c.outPointUs, false)
                            // keep the right edge anchored on the timeline
                            onMove(c.id, c.timelineStartUs + dUs, false)
                        }
                        is Drag.TrimOut -> onTrim(d.clip.id, d.clip.inPointUs, d.clip.outPointUs + (dUs * d.clip.speedValue()).toLong(), false)
                        null -> {}
                    }
                }
            }
            .pointerInput(Unit) {
                // commit on release
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent()
                        if (e.changes.all { !it.pressed }) {
                            when (val d = drag) {
                                is Drag.Move -> ui.project.findClip(d.clip.id)?.second?.let { onMove(it.id, it.timelineStartUs, true) }
                                is Drag.TrimIn -> ui.project.findClip(d.clip.id)?.second?.let { onTrim(it.id, it.inPointUs, it.outPointUs, true); onMove(it.id, it.timelineStartUs, true) }
                                is Drag.TrimOut -> ui.project.findClip(d.clip.id)?.second?.let { onTrim(it.id, it.inPointUs, it.outPointUs, true) }
                                else -> {}
                            }
                            drag = null
                        }
                    }
                }
            }
    ) {
        // ruler
        drawRect(PanelHi, Offset(0f, 0f), Size(size.width, RULER_H))
        val stepSec = when { pps > 200 -> 0.5f; pps > 80 -> 1f; pps > 30 -> 5f; else -> 10f }
        var s = (scrollPx / pps / stepSec).toInt() * stepSec
        while (true) {
            val x = s * pps - scrollPx
            if (x > size.width) break
            drawLine(Color.Gray, Offset(x, RULER_H - 6), Offset(x, RULER_H), 1f)
            drawContext.canvas.nativeCanvas.drawText(fmt(s.toDouble()).dropLast(3), x + 3, RULER_H - 7, labelPaint)
            s += stepSec
        }

        // tracks
        tracks.forEachIndexed { i, t ->
            val top = RULER_H + i * trackH
            drawRect(if (i % 2 == 0) Ink else Color(0xFF0F0F16), Offset(0f, top), Size(size.width, trackH))
            drawLine(PanelHi, Offset(0f, top + trackH), Offset(size.width, top + trackH), 1f)
            val color = when (t.kind) { TrackKind.VIDEO -> ClipVideo; TrackKind.AUDIO -> ClipAudio; TrackKind.TEXT -> ClipText; TrackKind.OVERLAY -> ClipOverlay }
            for (c in t.clips) {
                val xs = usToX(c.timelineStartUs); val xe = usToX(c.timelineEndUs)
                if (xe < 0 || xs > size.width) continue
                val selected = c.id == ui.selectedClipId
                drawRoundRect(color.copy(alpha = if (t.visible) 0.85f else 0.35f), Offset(xs, top + 3), Size(xe - xs, trackH - 6), androidx.compose.ui.geometry.CornerRadius(6f))
                if (selected) drawRoundRect(Color.White, Offset(xs, top + 3), Size(xe - xs, trackH - 6), androidx.compose.ui.geometry.CornerRadius(6f), style = Stroke(2.5f))
                // trim handles
                drawRect(Color.White.copy(alpha = 0.5f), Offset(xs + 2, top + 8), Size(3f, trackH - 16))
                drawRect(Color.White.copy(alpha = 0.5f), Offset(xe - 5, top + 8), Size(3f, trackH - 16))
                clipLabel(c, xs + 10, top + trackH / 2 + 4, xe - xs - 14, labelPaint)
                // keyframe diamonds (any animated prop or effect param)
                val kfTimes = (c.props.values.flatMap { it.keyframes } + c.effects.flatMap { e -> e.params.values.flatMap { it.keyframes } }).map { it.timeUs }.distinct()
                for (k in kfTimes) diamond(usToX(c.timelineStartUs + k), top + trackH - 7, 4f, KeyframeGold)
            }
        }

        // playhead
        val px = usToX(ui.playheadUs)
        drawLine(Accent, Offset(px, 0f), Offset(px, size.height), 2f)
        val tri = Path().apply { moveTo(px - 6, 0f); lineTo(px + 6, 0f); lineTo(px, 9f); close() }
        drawPath(tri, Accent)
    }
}

private fun DrawScope.clipLabel(c: Clip, x: Float, y: Float, maxW: Float, paint: android.graphics.Paint) {
    if (maxW < 20) return
    val label = if (c.kind == MediaKind.TEXT) "T " + c.name else c.name
    val txt = android.text.TextUtils.ellipsize(label, android.text.TextPaint(paint), maxW, android.text.TextUtils.TruncateAt.END).toString()
    drawContext.canvas.nativeCanvas.drawText(txt, x, y, paint)
}

private fun DrawScope.diamond(x: Float, y: Float, r: Float, color: Color) {
    val p = Path().apply { moveTo(x, y - r); lineTo(x + r, y); lineTo(x, y + r); lineTo(x - r, y); close() }
    drawPath(p, color)
}
