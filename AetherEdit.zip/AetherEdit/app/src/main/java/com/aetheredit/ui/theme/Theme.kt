package com.aetheredit.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF0B0B10)
val Panel = Color(0xFF15151D)
val PanelHi = Color(0xFF1F1F2A)
val Accent = Color(0xFF7C5CFF)
val AccentSoft = Color(0xFF3B2F7A)
val ClipVideo = Color(0xFF2E6FDB)
val ClipAudio = Color(0xFF2BA36B)
val ClipText = Color(0xFFD98A2B)
val ClipOverlay = Color(0xFFB3449A)
val KeyframeGold = Color(0xFFFFC857)
val TextDim = Color(0xFF9A9AB0)

private val scheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color.White,
    background = Ink,
    onBackground = Color(0xFFECECF4),
    surface = Panel,
    onSurface = Color(0xFFECECF4),
    surfaceVariant = PanelHi,
    onSurfaceVariant = TextDim,
    secondary = KeyframeGold,
)

@Composable
fun AetherTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
