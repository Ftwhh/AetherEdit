package com.aetheredit.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import com.aetheredit.ai.AiSettings
import com.aetheredit.ai.AutoCaptions
import com.aetheredit.ai.BackgroundRemover
import com.aetheredit.ai.ClipContext
import com.aetheredit.ai.CommandExecutor
import com.aetheredit.ai.EditCommand
import com.aetheredit.engine.EffectRegistry
import com.aetheredit.engine.ExportEngine
import com.aetheredit.engine.ExportState
import com.aetheredit.engine.Keyframes
import com.aetheredit.engine.MediaInfo
import com.aetheredit.engine.PreviewEngine
import com.aetheredit.model.AnimatedParam
import com.aetheredit.model.Clip
import com.aetheredit.model.Easing
import com.aetheredit.model.EffectInstance
import com.aetheredit.model.Keyframe
import com.aetheredit.model.MediaKind
import com.aetheredit.model.Project
import com.aetheredit.model.Prop
import com.aetheredit.model.TrackKind
import com.aetheredit.model.usToSec
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.io.File

data class EditorUiState(
    val project: Project = Project(),
    val selectedClipId: String? = null,
    val playheadUs: Long = 0L,
    val isPlaying: Boolean = false,
    val pixelsPerSecond: Float = 60f,
    val aiBusy: Boolean = false,
    val aiLog: List<String> = emptyList(),
    val export: ExportState? = null,
    val toast: String? = null,
    val panel: Panel = Panel.CLIPS,
) {
    val selectedClip: Clip? get() = selectedClipId?.let { project.findClip(it)?.second }
}

enum class Panel { CLIPS, INSPECTOR, EFFECTS, AI, EXPORT }

@UnstableApi
class EditorViewModel(app: Application) : AndroidViewModel(app) {

    private val _ui = MutableStateFlow(EditorUiState())
    val ui: StateFlow<EditorUiState> = _ui.asStateFlow()

    val preview = PreviewEngine(app)
    val aiSettings = AiSettings(app)
    private val bgRemover by lazy { BackgroundRemover(app) }
    private val captions by lazy { AutoCaptions(app) }

    private val undo = ArrayDeque<Project>()
    private val redo = ArrayDeque<Project>()
    private var ticker: Job? = null
    private val json = Json { prettyPrint = true; encodeDefaults = true }
    private val projectFile = File(app.filesDir, "autosave.json")

    init {
        runCatching { if (projectFile.exists()) json.decodeFromString(Project.serializer(), projectFile.readText()) }
            .getOrNull()?.let { p -> _ui.update { it.copy(project = p) }; preview.load(p) }
        ticker = viewModelScope.launch {
            while (isActive) {
                val playing = preview.player.isPlaying
                if (playing) _ui.update { it.copy(playheadUs = preview.timelinePositionUs(), isPlaying = true) }
                else if (_ui.value.isPlaying) _ui.update { it.copy(isPlaying = false) }
                delay(33)
            }
        }
    }

    val project get() = _ui.value.project

    // ---------- history ----------
    private fun commit(newProject: Project, rebuildPlaylist: Boolean = true) {
        undo.addLast(project); if (undo.size > 100) undo.removeFirst(); redo.clear()
        _ui.update { it.copy(project = newProject) }
        if (rebuildPlaylist) preview.load(newProject) else preview.refreshEffects(newProject)
        runCatching { projectFile.writeText(json.encodeToString(Project.serializer(), newProject)) }
    }
    fun undo() { val p = undo.removeLastOrNull() ?: return; redo.addLast(project); _ui.update { it.copy(project = p) }; preview.load(p) }
    fun redo() { val p = redo.removeLastOrNull() ?: return; undo.addLast(project); _ui.update { it.copy(project = p) }; preview.load(p) }
    val canUndo get() = undo.isNotEmpty()
    val canRedo get() = redo.isNotEmpty()

    // ---------- transport ----------
    fun togglePlay() = preview.togglePlay()
    fun seek(us: Long) { val c = us.coerceIn(0, maxOf(project.durationUs, 0)); _ui.update { it.copy(playheadUs = c) }; preview.seekTo(c) }
    fun setZoom(pps: Float) = _ui.update { it.copy(pixelsPerSecond = pps.coerceIn(10f, 400f)) }
    fun setPanel(p: Panel) = _ui.update { it.copy(panel = p) }
    fun select(clipId: String?) = _ui.update { it.copy(selectedClipId = clipId, panel = if (clipId != null && it.panel == Panel.CLIPS) Panel.INSPECTOR else it.panel) }
    fun toast(msg: String?) = _ui.update { it.copy(toast = msg) }

    // ---------- clips ----------
    fun importMedia(uris: List<Uri>) {
        if (uris.isEmpty()) return
        var p = project
        for (uri in uris) {
            runCatching { getApplication<Application>().contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val kind = MediaInfo.kindOf(getApplication(), uri)
            val track = when (kind) {
                MediaKind.AUDIO -> p.tracks.first { it.kind == TrackKind.AUDIO }
                else -> p.tracks.first { it.kind == TrackKind.VIDEO }
            }
            val clip = MediaInfo.clipFor(getApplication(), uri, track.endUs)
            p = p.addClip(track.id, clip)
        }
        commit(p)
    }

    fun addTextClip(text: String) {
        val t = project.tracks.first { it.kind == TrackKind.TEXT }
        val c = Clip(name = text, uri = "", kind = MediaKind.TEXT, timelineStartUs = _ui.value.playheadUs, inPointUs = 0,
            outPointUs = 3_000_000, sourceDurationUs = Long.MAX_VALUE / 4, textStyle = com.aetheredit.model.TextStyle(text = text))
        commit(project.addClip(t.id, c)); select(c.id)
    }

    fun deleteSelected() { val id = _ui.value.selectedClipId ?: return; commit(project.removeClip(id)); select(null) }
    fun splitAtPlayhead() { val id = _ui.value.selectedClipId ?: return; commit(CommandExecutor.split(project, id, _ui.value.playheadUs)) }
    fun duplicateSelected() {
        val (t, c) = _ui.value.selectedClipId?.let { project.findClip(it) } ?: return
        commit(project.addClip(t.id, c.copy(id = java.util.UUID.randomUUID().toString(), timelineStartUs = c.timelineEndUs)))
    }

    /** Live drag of a clip. [commitNow]=false only updates state (no history), true writes history. */
    fun moveClip(clipId: String, newStartUs: Long, commitNow: Boolean) {
        val p = project.updateClip(clipId) { it.copy(timelineStartUs = newStartUs.coerceAtLeast(0)) }
        if (commitNow) commit(resolveOverlaps(p, clipId)) else _ui.update { it.copy(project = p) }
    }

    fun trimClip(clipId: String, inUs: Long, outUs: Long, commitNow: Boolean) {
        val p = project.updateClip(clipId) { c ->
            val i = inUs.coerceIn(0, c.outPointUs - 100_000)
            val o = outUs.coerceIn(i + 100_000, if (c.kind == MediaKind.IMAGE || c.kind == MediaKind.TEXT) Long.MAX_VALUE / 8 else c.sourceDurationUs)
            c.copy(inPointUs = i, outPointUs = o)
        }
        if (commitNow) commit(p) else _ui.update { it.copy(project = p) }
    }

    /** Main video track is a sequence: keep clips contiguous & ordered after a move. */
    private fun resolveOverlaps(p: Project, movedId: String): Project {
        val track = p.findClip(movedId)?.first ?: return p
        if (track.kind != TrackKind.VIDEO) return p
        var t = 0L
        val ordered = track.clips.sortedBy { it.timelineStartUs }.map { c -> c.copy(timelineStartUs = t).also { t += c.durationUs } }
        return p.copy(tracks = p.tracks.map { if (it.id == track.id) it.copy(clips = ordered) else it })
    }

    // ---------- properties & keyframes ----------
    fun selectedLocalTimeUs(): Long { val c = _ui.value.selectedClip ?: return 0L; return (_ui.value.playheadUs - c.timelineStartUs).coerceAtLeast(0) }

    fun currentValue(prop: String): Float { val c = _ui.value.selectedClip ?: return 0f; return Keyframes.evaluate(c.prop(prop), selectedLocalTimeUs()) }
    fun currentEffectValue(e: EffectInstance, param: String): Float {
        val spec = EffectRegistry.byId(e.typeId)?.params?.first { it.id == param }
        return e.params[param]?.let { Keyframes.evaluate(it, selectedLocalTimeUs()) } ?: spec?.default ?: 0f
    }

    /** Sets a transform prop; if the prop is animated, writes/updates a keyframe at the playhead (AE "stopwatch" behaviour). */
    fun setProp(prop: String, value: Float, commitNow: Boolean) {
        val id = _ui.value.selectedClipId ?: return
        val p = project.updateClip(id) { c -> c.withProp(prop, updated(c.prop(prop), value)) }
        if (commitNow) commit(p, rebuildPlaylist = prop == Prop.SPEED) else { _ui.update { it.copy(project = p) }; preview.refreshEffects(p) }
    }

    fun setEffectParam(effectId: String, param: String, value: Float, commitNow: Boolean) {
        val id = _ui.value.selectedClipId ?: return
        val p = project.updateClip(id) { c ->
            c.copy(effects = c.effects.map { e -> if (e.id != effectId) e else e.copy(params = e.params + (param to updated(e.params[param] ?: AnimatedParam.of(value), value))) })
        }
        if (commitNow) commit(p, false) else { _ui.update { it.copy(project = p) }; preview.refreshEffects(p) }
    }

    private fun updated(param: AnimatedParam, value: Float): AnimatedParam =
        if (param.isAnimated) param.withKeyframe(Keyframe(selectedLocalTimeUs(), value, easingFor(param))) else param.copy(value = value)

    private fun easingFor(param: AnimatedParam): Easing = Keyframes.nearest(param, selectedLocalTimeUs(), 1)?.easing ?: Easing.EASE_IN_OUT

    fun toggleKeyframe(prop: String, effectId: String? = null) {
        val id = _ui.value.selectedClipId ?: return
        val t = selectedLocalTimeUs()
        val p = project.updateClip(id) { c ->
            if (effectId == null) {
                val cur = c.prop(prop)
                val v = Keyframes.evaluate(cur, t)
                c.withProp(prop, if (Keyframes.nearest(cur, t, 16_000) != null) cur.removeKeyframeAt(t) else cur.withKeyframe(Keyframe(t, v)))
            } else c.copy(effects = c.effects.map { e ->
                if (e.id != effectId) e else {
                    val cur = e.params[prop] ?: AnimatedParam.of(currentEffectValue(e, prop))
                    val v = Keyframes.evaluate(cur, t)
                    e.copy(params = e.params + (prop to if (Keyframes.nearest(cur, t, 16_000) != null) cur.removeKeyframeAt(t) else cur.withKeyframe(Keyframe(t, v))))
                }
            })
        }
        commit(p, false)
    }

    fun setKeyframeEasing(prop: String, effectId: String?, easing: Easing) {
        val id = _ui.value.selectedClipId ?: return
        val t = selectedLocalTimeUs()
        fun fix(a: AnimatedParam) = a.copy(keyframes = a.keyframes.map { if (kotlin.math.abs(it.timeUs - t) <= 16_000) it.copy(easing = easing) else it })
        val p = project.updateClip(id) { c ->
            if (effectId == null) c.withProp(prop, fix(c.prop(prop)))
            else c.copy(effects = c.effects.map { e -> if (e.id != effectId) e else e.copy(params = e.params.mapValues { (k, v) -> if (k == prop) fix(v) else v }) })
        }
        commit(p, false)
    }

    fun clearAnimation(prop: String, effectId: String?) {
        val id = _ui.value.selectedClipId ?: return
        val v = if (effectId == null) currentValue(prop) else _ui.value.selectedClip?.effects?.first { it.id == effectId }?.let { currentEffectValue(it, prop) } ?: 0f
        val p = project.updateClip(id) { c ->
            if (effectId == null) c.withProp(prop, AnimatedParam.of(v))
            else c.copy(effects = c.effects.map { e -> if (e.id != effectId) e else e.copy(params = e.params + (prop to AnimatedParam.of(v))) })
        }
        commit(p, false)
    }

    // ---------- effects ----------
    fun addEffect(typeId: String) {
        val id = _ui.value.selectedClipId ?: return
        val type = EffectRegistry.byId(typeId) ?: return
        commit(project.updateClip(id) { it.copy(effects = it.effects + type.newInstance()) }, false)
        setPanel(Panel.INSPECTOR)
    }
    fun removeEffect(effectId: String) { val id = _ui.value.selectedClipId ?: return; commit(project.updateClip(id) { c -> c.copy(effects = c.effects.filterNot { it.id == effectId }) }, false) }
    fun toggleEffect(effectId: String) { val id = _ui.value.selectedClipId ?: return; commit(project.updateClip(id) { c -> c.copy(effects = c.effects.map { if (it.id == effectId) it.copy(enabled = !it.enabled) else it }) }, false) }
    fun moveEffect(effectId: String, delta: Int) {
        val id = _ui.value.selectedClipId ?: return
        commit(project.updateClip(id) { c ->
            val l = c.effects.toMutableList(); val i = l.indexOfFirst { it.id == effectId }; val j = i + delta
            if (i >= 0 && j in l.indices) { val e = l.removeAt(i); l.add(j, e) }
            c.copy(effects = l)
        }, false)
    }

    // ---------- AI ----------
    fun runAi(instruction: String) {
        val clip = _ui.value.selectedClip ?: run { toast("Select a clip first"); return }
        viewModelScope.launch {
            _ui.update { it.copy(aiBusy = true, aiLog = it.aiLog + "› $instruction") }
            val provider = aiSettings.provider()
            val ctx = ClipContext(clip.name, clip.durationUs.usToSec().toFloat(), clip.effects.map { it.typeId })
            val cmds = runCatching { provider.parse(instruction, ctx) }.getOrElse { listOf(EditCommand.Say("AI failed: ${it.message}")) }
            val res = CommandExecutor.apply(project, clip.id, cmds)
            if (res.project != project) commit(res.project)
            _ui.update { it.copy(aiLog = it.aiLog + res.notes.map { n -> "• $n" }) }
            if (res.needsBgRemoval) removeBackground(clip.id)
            if (res.needsCaptions) generateCaptions(clip.id)
            _ui.update { it.copy(aiBusy = false) }
        }
    }

    fun removeBackground(clipId: String) = viewModelScope.launch {
        val clip = project.findClip(clipId)?.second ?: return@launch
        if (!bgRemover.isModelAvailable()) { log("Add selfie_segmenter.tflite to assets to enable background removal."); return@launch }
        runCatching {
            when (clip.kind) {
                MediaKind.IMAGE -> {
                    val out = bgRemover.cutoutImage(Uri.parse(clip.uri))
                    val overlay = project.tracks.first { it.kind == TrackKind.OVERLAY }
                    commit(project.removeClip(clipId).addClip(overlay.id, clip.copy(uri = out.toString())))
                    log("Background removed; clip moved to the overlay track.")
                }
                MediaKind.VIDEO -> {
                    val rgb = bgRemover.estimateBackgroundColor(Uri.parse(clip.uri), clip.inPointUs + clip.durationUs / 2)
                    val type = EffectRegistry.byId("chroma_key")!!
                    val inst = type.newInstance().let { e -> e.copy(params = e.params + mapOf("kr" to AnimatedParam.of(rgb[0]), "kg" to AnimatedParam.of(rgb[1]), "kb" to AnimatedParam.of(rgb[2]))) }
                    commit(project.updateClip(clipId) { it.copy(effects = it.effects.filterNot { e -> e.typeId == "chroma_key" } + inst) }, false)
                    log("Keyed background colour (%.2f, %.2f, %.2f). Tune Similarity in the inspector.".format(rgb[0], rgb[1], rgb[2]))
                }
                else -> log("Background removal works on video and image clips.")
            }
        }.onFailure { log("Background removal failed: ${it.message}") }
    }

    fun generateCaptions(clipId: String) = viewModelScope.launch {
        val clip = project.findClip(clipId)?.second ?: return@launch
        if (!captions.isModelAvailable()) { log("Add a Vosk model folder to assets/model-en-us to enable offline captions."); return@launch }
        runCatching {
            val segs = captions.transcribe(Uri.parse(clip.uri), clip.inPointUs, clip.outPointUs)
            val textTrack = project.tracks.first { it.kind == TrackKind.TEXT }
            var p = project
            captions.toTextClips(clip, segs).forEach { p = p.addClip(textTrack.id, it) }
            commit(p)
            log("Added ${segs.size} caption segments.")
        }.onFailure { log("Captions failed: ${it.message}") }
    }

    private fun log(s: String) = _ui.update { it.copy(aiLog = it.aiLog + "• $s") }

    // ---------- export ----------
    fun export() = viewModelScope.launch {
        preview.pause()
        val out = File(getApplication<Application>().filesDir, "exports/${project.name.replace(' ', '_')}_${System.currentTimeMillis()}.mp4")
        ExportEngine.export(getApplication(), project, out).collect { st -> _ui.update { it.copy(export = st) } }
    }
    fun clearExport() = _ui.update { it.copy(export = null) }

    fun setAspect(w: Int, h: Int) = commit(project.copy(width = w, height = h), false)
    fun rename(n: String) = commit(project.copy(name = n), false)

    override fun onCleared() { ticker?.cancel(); preview.release(); runCatching { captions.close() }; runCatching { bgRemover.close() } }
}
